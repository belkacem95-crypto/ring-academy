/* =========================================================
   أكاديمية الحلبة — واجهة الكورسات
   الكورسات ثابتة، تُبنى مع التطبيق. هنا نعرضها ونفعّلها فقط.
   ========================================================= */

(function () {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const esc = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));
  const isolate = (value) => `\u2066${value}\u2069`;

  let els = null;

  function init() {
    els = {
      summary: $('#bankSummary'),
      list: $('#bankCourseList'),
      chips: $('#quizCourses')
    };
    if (!els.list || !window.RingCatalog) return;
    bind();
    render();
    document.addEventListener('ringcatalogchange', render);
  }

  function coursesLabel(count) {
    if (count === 1) return 'كورس واحد مفعّل';
    if (count === 2) return 'كورسان مفعّلان';
    if (count >= 3 && count <= 10) return `${count} كورسات مفعّلة`;
    return `${count} كورسًا مفعّلًا`;
  }

  function render() {
    if (!els) return;
    renderSummary();
    renderList();
    renderChips();
  }

  function renderSummary() {
    if (!els.summary) return;
    const catalog = RingCatalog.counts();
    els.summary.innerHTML = `<strong>${isolate(catalog.questions)} سؤالًا</strong> · ${esc(coursesLabel(catalog.active))} · ${isolate(catalog.themes)} محاور`;
  }

  function themeChips(course) {
    const themes = Object.values(course.categories || {});
    const shown = themes.slice(0, 6).map((theme) => (
      `<span class="course-theme">${esc(theme.label)}</span>`
    ));
    if (themes.length > 6) shown.push(`<span class="course-theme is-more">+${isolate(themes.length - 6)}</span>`);
    return shown.join('');
  }

  function cardHtml(course) {
    const active = RingCatalog.isSelected(course.id);
    return `
      <article class="course-card${active ? ' is-active' : ''}" data-course="${esc(course.id)}">
        <label class="course-toggle" title="${active ? 'إيقاف هذا الكورس' : 'تفعيل هذا الكورس'}">
          <input type="checkbox" data-course-toggle="${esc(course.id)}"${active ? ' checked' : ''}>
          <span class="course-toggle-box" aria-hidden="true"></span>
        </label>
        <div class="course-body">
          <div class="course-title">
            <strong>${esc(course.name)}</strong>
            <span class="course-badge">${esc(course.short)}</span>
          </div>
          <small>${isolate(course.questions.length)} سؤالًا · ${isolate(course.modules.length)} وحدات · ${isolate(Object.keys(course.categories).length)} محاور</small>
          <small>${esc(course.desc)}</small>
          <div class="course-themes">${themeChips(course)}</div>
        </div>
      </article>`;
  }

  function renderList() {
    if (!els.list) return;
    if (!RingCatalog.courses.length) {
      els.list.innerHTML = '<p class="course-empty">لا يوجد كورس في هذا الإصدار.</p>';
      return;
    }
    els.list.innerHTML = RingCatalog.courses.map(cardHtml).join('');
  }

  function renderChips() {
    if (!els.chips) return;
    const active = RingCatalog.activeCourses();
    els.chips.innerHTML = `
      <span class="quiz-course-label">الكورسات المفعّلة</span>
      <div class="quiz-course-chips">
        ${RingCatalog.courses.map((course) => {
          const isActive = RingCatalog.isSelected(course.id);
          return `<button type="button" class="course-chip${isActive ? ' is-active' : ''}" data-quiz-course="${esc(course.id)}" aria-pressed="${isActive ? 'true' : 'false'}">
            <span>${esc(course.short)}</span>
            <small>${isolate(course.questions.length)}</small>
          </button>`;
        }).join('')}
        <a class="course-manage" href="#sessions" data-nav="sessions">إدارة الكورسات ←</a>
      </div>
      <small class="quiz-course-note">${active.length > 1
        ? `تُدمج أسئلة ${isolate(active.length)} كورسات، وتظهر محاورها معًا في الاختبار والجلسات.`
        : 'فعّل كورسًا آخر لتضمين أسئلته في الاختبار والجلسات.'}</small>`;
  }

  function toggleFromList(id, input) {
    const ok = RingCatalog.toggle(id);
    if (!ok) {
      input.checked = true;
      window.alert('يجب أن يبقى كورس واحد مفعّلًا على الأقل.');
      return;
    }
    render();
  }

  function bind() {
    document.addEventListener('change', (event) => {
      const toggle = event.target.closest('[data-course-toggle]');
      if (!toggle) return;
      toggleFromList(toggle.dataset.courseToggle, toggle);
    });

    document.addEventListener('click', (event) => {
      const chip = event.target.closest('[data-quiz-course]');
      if (!chip) return;
      const id = chip.dataset.quizCourse;
      const ok = RingCatalog.toggle(id);
      if (!ok) {
        window.alert('يجب أن يبقى كورس واحد مفعّلًا على الأقل.');
        return;
      }
      render();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.RingCourses = { render, refresh: render };
})();
