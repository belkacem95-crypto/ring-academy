/* =========================================================
   أكاديمية الحلبة — كتالوج الكورسات
   يقرأ ملفات الكورسات الثابتة (js/courses/*.js) ويبني منها
   CATEGORIES وQUESTIONS وMODULES وSIGNALS حسب الكورسات المفعّلة.
   الاختيار يُحفظ محليًا؛ لا استيراد داخل التطبيق.
   ========================================================= */

(function () {
  'use strict';

  const STORE_KEY = 'ringAcademy.catalog.v1';
  const files = (window.RingCourseFiles || []).slice().sort((a, b) => (a.order || 0) - (b.order || 0));

  /* Dans le coach, les assets sont à la racine. Dans l'application Cours
     ouverte depuis les sources, ils sont deux niveaux au-dessus. */
  const assetBase = document.documentElement.getAttribute('data-asset-base') || '';
  const asset = (path) => (path ? assetBase + path : path);

  function copy(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function loadSelection() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.selected)) return null;
      const known = parsed.selected.filter((id) => files.some((file) => file.id === id));
      return known.length ? known : null;
    } catch (error) {
      return null;
    }
  }

  function saveSelection() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ selected: selected.slice() }));
    } catch (error) {
      /* stockage indisponible : l'choix reste en mémoire */
    }
  }

  /* Une clé de thème déjà utilisée par un autre cours reçoit un préfixe,
     pour que CATEGORIES, MODULES et question.cat restent cohérents. */
  function uniqueKey(course, key, used) {
    return used.has(key) ? `${course.id}:${key}` : key;
  }

  function buildCourse(file, usedCategories) {
    const categories = {};
    const catMap = {};

    Object.keys(file.categories || {}).forEach((key) => {
      const mapped = uniqueKey(file, key, usedCategories);
      usedCategories.add(mapped);
      catMap[key] = mapped;
      categories[mapped] = Object.assign({}, file.categories[key], {
        course: file.id,
        img: asset(file.categories[key].img)
      });
    });

    const modules = (file.modules || []).map((module) => {
      const mapped = catMap[module.id] || module.id;
      return Object.assign({}, module, {
        id: mapped,
        key: module.id,
        course: file.id,
        courseName: file.name,
        courseShort: file.short || file.name,
        img: asset(module.img)
      });
    });

    const questions = (file.questions || []).map((question) => Object.assign({}, question, {
      cat: catMap[question.cat] || question.cat,
      course: file.id,
      img: asset(question.img)
    }));

    const signals = (file.signals || []).map((signal) => Object.assign({}, signal, {
      course: file.id,
      src: asset(`assets/img/${signal.file}`)
    }));

    return {
      id: file.id,
      name: file.name,
      short: file.short || file.name,
      desc: file.desc || '',
      source: file.source || '',
      color: file.color || '#3b82f6',
      categories: categories,
      catMap: catMap,
      modules: modules,
      questions: questions,
      signals: signals
    };
  }

  const used = new Set();
  const allCourses = files.map((file) => buildCourse(file, used));

  let selected = loadSelection() || allCourses.map((course) => course.id);

  function activeCourses() {
    const active = allCourses.filter((course) => selected.indexOf(course.id) >= 0);
    return active.length ? active : allCourses;
  }

  /* Reconstruit les globales lues par l'application. */
  function rebuild() {
    const pool = activeCourses();
    const categories = {};
    const questions = [];
    const modules = [];
    const signals = [];

    pool.forEach((course) => {
      Object.keys(course.categories).forEach((key) => {
        categories[key] = course.categories[key];
      });
      course.questions.forEach((question) => questions.push(question));
      course.modules.forEach((module) => modules.push(module));
      course.signals.forEach((signal) => signals.push(signal));
    });

    window.COURSES = allCourses;
    window.ACTIVE_COURSES = pool;
    window.CATEGORIES = categories;
    window.QUESTIONS = questions;
    window.MODULES = modules;
    window.SIGNALS = signals;
  }

  function notify() {
    rebuild();
    document.dispatchEvent(new CustomEvent('ringcatalogchange'));
    document.dispatchEvent(new CustomEvent('ringbankchange'));
  }

  function setSelected(ids) {
    const clean = (Array.isArray(ids) ? ids : [])
      .filter((id, index, list) => allCourses.some((course) => course.id === id) && list.indexOf(id) === index);
    if (!clean.length) return false;
    selected = clean;
    saveSelection();
    notify();
    return true;
  }

  function toggle(id) {
    if (!allCourses.some((course) => course.id === id)) return false;
    const isActive = selected.indexOf(id) >= 0;
    if (isActive && selected.length === 1) return false;
    return setSelected(isActive ? selected.filter((item) => item !== id) : selected.concat(id));
  }

  function isSelected(id) {
    return selected.indexOf(id) >= 0;
  }

  function courseById(id) {
    return allCourses.find((course) => course.id === id) || null;
  }

  function counts() {
    return {
      courses: allCourses.length,
      active: activeCourses().length,
      questions: window.QUESTIONS.length,
      modules: window.MODULES.length,
      themes: Object.keys(window.CATEGORIES).length,
      signals: window.SIGNALS.length
    };
  }

  rebuild();

  window.RingCatalog = {
    version: 2,
    courses: allCourses,
    getSelected: () => selected.slice(),
    activeCourses: activeCourses,
    setSelected: setSelected,
    toggle: toggle,
    isSelected: isSelected,
    courseById: courseById,
    counts: counts,
    rebuild: rebuild,
    copy: copy
  };
})();
