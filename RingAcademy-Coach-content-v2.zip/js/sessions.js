/* =========================================================
   أكاديمية الحلبة — إدارة الجلسات (تطبيق المدرب)
   يعتمد على جسر Java « window.Coach » داخل تطبيق أندرويد.
   ========================================================= */

(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const STORE_KEY = 'ringAcademy.sessions.v1';
  const isMock = /(?:\?|&)mock=1(?:&|$)/.test(location.search);
  const nativeBridge = window.Coach || null;
  const bridge = nativeBridge || (isMock ? createMockBridge() : null);

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));

  const isolate = (value) => `\u2066${value}\u2069`;

  let config = loadConfig();
  let live = null;
  let liveAt = 0;
  let pollTimer = null;
  let tickTimer = null;
  let resultsCache = null;
  let detailName = null;
  let busy = false;

  /* ------------------------------------------------------------------ */
  /* الإعدادات                                                          */
  /* ------------------------------------------------------------------ */

  function loadConfig() {
    const base = { cat: 'all', count: 20, duration: 600, shuffle: true, level: 'advanced', title: 'ندوة تحكيم واكو' };
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return base;
      const parsed = JSON.parse(raw);
      return {
        cat: parsed.cat && (parsed.cat === 'all' || CATEGORIES[parsed.cat]) ? parsed.cat : 'all',
        count: parsed.count === 'all' ? 'all' : [10, 20].includes(Number(parsed.count)) ? Number(parsed.count) : 20,
        duration: [300, 600, 900, 1200].includes(Number(parsed.duration)) ? Number(parsed.duration) : 600,
        shuffle: parsed.shuffle !== false,
        level: parsed.level === 'all' ? 'all' : 'advanced',
        title: typeof parsed.title === 'string' && parsed.title.trim() ? parsed.title.slice(0, 60) : base.title
      };
    } catch (error) {
      return base;
    }
  }

  function saveConfig() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(config));
    } catch (error) {
      /* stockage indisponible : la configuration reste en mémoire */
    }
  }

  function availableCount(cat) {
    return poolFor(cat).length;
  }

  /* المستوى: «الكل» أو «متقدّم وما فوق». الأسئلة في الملفات قد تحمل مستويات
     بأسماء مختلفة (أساسي/متوسط/متقدّم/متقدم/خبير)، لذلك نُطبّع التشكيل قبل
     المقارنة. الافتراضي هو المستوى الصعب حتى يقيس الامتحان فعليًا مدى
     استيعاب المشاركين. */
  function levelRank(level) {
    const text = String(level || '').replace(/[\u064B-\u0652]/g, '');
    if (text.indexOf('خبير') !== -1) return 3;
    if (text.indexOf('متقد') !== -1) return 2;
    if (text.indexOf('متوسط') !== -1) return 1;
    return 1;
  }

  function poolFor(cat) {
    return QUESTIONS.filter((question) => {
      if (cat !== 'all' && question.cat !== cat) return false;
      return config.level === 'all' || levelRank(question.level) >= 2;
    });
  }

  function levelLabel(level) {
    return level === 'all' ? 'كل المستويات' : 'متقدّم وما فوق';
  }

  function selectedCount() {
    const available = availableCount(config.cat);
    return config.count === 'all' ? available : Math.min(config.count, available);
  }

  function countLabel(count) {
    if (count === 1) return 'سؤال واحد';
    if (count === 2) return 'سؤالان';
    if (count >= 3 && count <= 10) return `${count} أسئلة`;
    return `${count} سؤالًا`;
  }

  function categoryLabel(cat) {
    return cat === 'all' ? 'كل الأسئلة' : (CATEGORIES[cat] ? CATEGORIES[cat].label : 'كل الأسئلة');
  }

  function durationLabel(seconds) {
    const minutes = Math.round(seconds / 60);
    return minutes === 1 ? 'دقيقة واحدة' : minutes === 2 ? 'دقيقتان' : `${minutes} دقائق`;
  }

  function formatClock(ms) {
    const total = Math.max(0, Math.round((Number(ms) || 0) / 1000));
    const minutes = Math.floor(total / 60);
    return isolate(`${String(minutes).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`);
  }

  function formatTime(ms) {
    const total = Math.max(0, Math.round((Number(ms) || 0) / 1000));
    const minutes = Math.floor(total / 60);
    const seconds = total % 60;
    if (minutes === 0) return isolate(`${seconds} ث`);
    return isolate(`${minutes} د ${String(seconds).padStart(2, '0')} ث`);
  }

  /* ------------------------------------------------------------------ */
  /* الشاشة                                                            */
  /* ------------------------------------------------------------------ */

  function render() {
    if (currentView() !== 'sessions') {
      stopPolling();
      return;
    }

    if (!bridge) {
      showSetup();
      const note = $('#sessionBridgeNote');
      note.hidden = false;
      note.textContent = 'هذه الشاشة تعمل داخل تطبيق المدرب على الهاتف. افتح التطبيق على جهاز أندرويد لإنشاء جلسة حقيقية.';
      $('#startSessionBtn').disabled = true;
      return;
    }

    const state = readState();
    if (state && state.phase && state.phase !== 'idle') {
      live = state;
      liveAt = Date.now();
      showLive();
      poll();
    } else {
      showSetup();
      refreshInfo();
    }
  }

  function showSetup() {
    $('#sessionSetup').hidden = false;
    $('#sessionLive').hidden = true;
    resultsCache = null;
    detailName = null;
    stopPolling();
    renderSetup();
  }

  function showLive() {
    $('#sessionSetup').hidden = true;
    $('#sessionLive').hidden = false;
    renderLive();
    startPolling();
  }

  function renderSetup() {
    if (!bridge) {
      $('#startSessionBtn').disabled = true;
    }

    const allCard = `
      <button class="cat-card cat-card-all${config.cat === 'all' ? ' is-selected' : ''}" type="button" data-session-cat="all">
        <span class="cat-icon" style="--accent:#e63946">
          <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="4" width="6.5" height="6.5" rx="1.2" stroke="currentColor" stroke-width="1.6"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.2" stroke="currentColor" stroke-width="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.2" stroke="currentColor" stroke-width="1.6"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.2" stroke="currentColor" stroke-width="1.6"/></svg>
        </span>
        <span class="cat-text">
          <strong>كل الأسئلة</strong>
          <small>${countLabel(availableCount('all'))} · ${Object.keys(CATEGORIES).length} محاور</small>
        </span>
        <span class="cat-check" aria-hidden="true"></span>
      </button>`;

    const cards = Object.entries(CATEGORIES).map(([key, category]) => `
      <button class="cat-card${config.cat === key ? ' is-selected' : ''}" type="button" data-session-cat="${esc(key)}">
        <span class="cat-icon cat-icon-photo" style="--accent:${esc(category.color)}">
          ${category.img
            ? `<img src="${esc(category.img)}" alt="">`
            : '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="4.5" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/></svg>'}
        </span>
        <span class="cat-text">
          <strong>${esc(category.label)}</strong>
          <small>${countLabel(availableCount(key))}</small>
        </span>
        <span class="cat-check" aria-hidden="true"></span>
      </button>`).join('');

    $('#sessionCatGrid').innerHTML = allCard + cards;
    $('#sessionTitleInput').value = config.title;
    $$('#sessionCountPicker .count-btn').forEach((button) => {
      button.classList.toggle('is-selected', String(config.count) === button.dataset.count);
    });
    $$('#sessionDurationPicker .count-btn').forEach((button) => {
      button.classList.toggle('is-selected', String(config.duration) === button.dataset.duration);
    });
    $('#sessionShuffleToggle').checked = config.shuffle;
    $$('#sessionLevelPicker .count-btn').forEach((button) => {
      button.classList.toggle('is-selected', button.dataset.level === config.level);
    });

    const available = availableCount(config.cat);
    const requested = config.count === 'all' ? available : Number(config.count);
    const levelNote = $('#sessionLevelNote');
    if (levelNote) {
      if (available === 0) {
        levelNote.hidden = false;
        levelNote.textContent = 'لا توجد أسئلة بهذا المستوى في هذا المحور. اختر «الكل» أو محورًا آخر.';
      } else if (requested > available) {
        levelNote.hidden = false;
        levelNote.textContent = `المتاح في هذا المحور وهذا المستوى: ${countLabel(available)} فقط.`;
      } else {
        levelNote.hidden = true;
        levelNote.textContent = '';
      }
    }

    const count = selectedCount();
    $('#sessionSummary').textContent = `${countLabel(count)} · ${categoryLabel(config.cat)} · ${levelLabel(config.level)} · ${durationLabel(config.duration)}`;
    $('#startSessionBtn').disabled = Boolean(!bridge) || count === 0;
  }

  function refreshInfo() {
    if (!bridge) return;
    const strong = $('#sessionIps');
    const note = $('#sessionIpsNote');
    try {
      const info = JSON.parse(bridge.info());
      const ips = Array.isArray(info.ips) ? info.ips.filter(Boolean) : [];
      const port = info.port || 8765;
      if (!ips.length) {
        strong.textContent = '—';
        delete strong.dataset.ip;
        if (note) note.textContent = 'لم يُعثر على شبكة. فعّل نقطة الاتصال من الهاتف ثم أعد المحاولة.';
        return;
      }
      strong.textContent = `${ips[0]}:${port}`;
      strong.dataset.ip = ips[0];
      if (note) {
        const lan = /^(192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ips[0]);
        if (!lan) {
          note.textContent = 'إذا كان هذا عنوان بيانات محمولة، فعّل «نقطة اتصال Wi-Fi» ثم أعد فتح الجلسة.';
        } else if (ips.length > 1) {
          note.textContent = `عناوين أخرى على الهاتف: ${ips.slice(1).map((ip) => `${ip}`).join(' · ')}`;
        } else {
          note.textContent = 'هذا هو العنوان الذي يتّصل به تطبيق الامتحان.';
        }
      }
    } catch (error) {
      strong.textContent = '—';
      delete strong.dataset.ip;
      if (note) note.textContent = 'تعذّر قراءة عنوان الشبكة.';
    }
  }

  /* ------------------------------------------------------------------ */
  /* إنشاء الجلسة                                                       */
  /* ------------------------------------------------------------------ */

  function startSession() {
    if (!bridge || busy) return;
    busy = true;
    $('#startSessionBtn').disabled = true;

    const pool = poolFor(config.cat);
    const ordered = config.shuffle ? shuffle(pool) : pool;
    const questions = ordered.slice(0, Math.min(selectedCount(), ordered.length));

    const payload = questions.map((question) => {
      const mixed = withShuffledOptions(question);
      return {
        id: mixed.id,
        cat: mixed.cat,
        level: mixed.level,
        q: mixed.q,
        options: mixed.options,
        answer: mixed.answer,
        img: mixed.img,
        alt: mixed.alt,
        exp: mixed.exp,
        source: mixed.source
      };
    });

    let response;
    try {
      response = JSON.parse(bridge.start(
        JSON.stringify({ title: config.title.trim() || 'جلسة أكاديمية الحلبة', durationSec: config.duration, shuffle: config.shuffle }),
        JSON.stringify(payload)
      ));
    } catch (error) {
      response = { ok: false, error: 'bridge' };
    }

    busy = false;

    if (!response.ok) {
      $('#startSessionBtn').disabled = false;
      toast(startError(response.error));
      return;
    }

    resultsCache = null;
    live = {
      ok: true,
      active: true,
      phase: 'lobby',
      code: response.code,
      port: response.port,
      ips: response.ips || [],
      title: config.title,
      total: response.total,
      durationSec: response.durationSec,
      startedAt: 0,
      endsAt: 0,
      remainingMs: response.durationSec * 1000,
      participants: []
    };
    liveAt = Date.now();
    showLive();
    poll();
  }

  function startError(code) {
    if (code === 'port') return 'تعذّر فتح المنفذ 8765. أغلق أيّ تطبيق آخر يستخدمه ثم أعد المحاولة.';
    if (code === 'questions') return 'لا توجد أسئلة صالحة في هذا المحور.';
    return 'تعذّر إنشاء الجلسة. أعد المحاولة.';
  }

  /* ------------------------------------------------------------------ */
  /* المزامنة مع الخادم                                                 */
  /* ------------------------------------------------------------------ */

  function readState() {
    if (!bridge) return null;
    try {
      return JSON.parse(bridge.state());
    } catch (error) {
      return null;
    }
  }

  function poll() {
    if (!bridge) return;
    const state = readState();
    if (!state) return;
    live = state;
    liveAt = Date.now();
    if (!state.phase || state.phase === 'idle') {
      showSetup();
      refreshInfo();
      return;
    }
    if ($('#sessionLive').hidden) showLive();
    renderLive();
    if (state.phase === 'lobby' || state.phase === 'running') startPolling();
    else stopPolling();
  }

  function startPolling() {
    if (pollTimer) return;
    pollTimer = setInterval(poll, 1000);
    if (!tickTimer) tickTimer = setInterval(tickClock, 400);
  }

  function stopPolling() {
    if (pollTimer) clearInterval(pollTimer);
    if (tickTimer) clearInterval(tickTimer);
    pollTimer = null;
    tickTimer = null;
  }

  function remainingNow() {
    if (!live) return 0;
    if (live.phase === 'lobby') return (live.durationSec || 0) * 1000;
    if (live.phase !== 'running') return 0;
    const elapsed = Date.now() - liveAt;
    return Math.max(0, (live.remainingMs || 0) - elapsed);
  }

  function tickClock() {
    if (!live) return;
    const clock = $('#liveClock');
    if (clock) clock.textContent = formatClock(remainingNow());
  }

  /* ------------------------------------------------------------------ */
  /* عرض الجلسة المباشرة                                                */
  /* ------------------------------------------------------------------ */

  function renderLive() {
    if (!live) return;

    const phase = live.phase || 'lobby';
    const participants = Array.isArray(live.participants) ? live.participants : [];
    const done = participants.filter((participant) => participant.submitted);
    const phaseLabels = {
      lobby: 'في الانتظار',
      running: 'الجلسة جارية',
      ended: 'انتهت الجلسة',
      stopped: 'موقوفة'
    };

    $('#liveCode').textContent = live.code || '----';
    $('#livePhase').textContent = phaseLabels[phase] || phase;
    $('#livePhase').className = `status-pill session-phase is-${phase}`;
    $('#liveTitle').textContent = live.title || 'الجلسة';
    $('#liveIps').textContent = live.ips && live.ips.length
      ? `العنوان: ${isolate(`${live.ips[0]}:${live.port || 8765}`)}${live.ips.length > 1 ? ' — أعطِه لمن لم يتّصل تلقائيًا' : ''}`
      : 'لم يُعثر على عنوان شبكة. تحقّق من نقطة الاتصال.';

    if (phase === 'lobby') {
      $('#liveInfo').textContent = `${countLabel(live.total || 0)} · ${durationLabel(live.durationSec || 0)}. شارك الرمز وابدأ عندما يكون الجميع جاهزًا.`;
    } else if (phase === 'running') {
      $('#liveInfo').textContent = `${countLabel(live.total || 0)} · ${durationLabel(live.durationSec || 0)}. الإجابات تُسجّل مباشرة.`;
    } else {
      $('#liveInfo').textContent = `${countLabel(live.total || 0)} · اكتملت الجلسة. اضغط على اسم لعرض نسخته.`;
    }

    $('#liveClock').textContent = formatClock(remainingNow());
    $('#liveCount').textContent = isolate(String(participants.length));
    $('#liveDone').textContent = isolate(`${done.length} / ${participants.length}`);

    $('#startExamBtn').hidden = phase !== 'lobby';
    $('#startExamBtn').disabled = participants.length === 0;
    $('#finishExamBtn').hidden = phase !== 'running';
    $('#stopSessionBtn').textContent = phase === 'ended' || phase === 'stopped' ? 'جلسة جديدة' : 'إيقاف';
    $('#stopSessionBtn').className = `btn ${phase === 'ended' || phase === 'stopped' ? 'btn-primary' : 'btn-outline'}`;

    if (!participants.length) {
      $('#liveParticipants').innerHTML = `
        <div class="participant-empty">
          <span class="wait-dots" aria-hidden="true"><i></i><i></i><i></i></span>
          <p>لم ينضمّ أحد بعد. تأكّد من نقطة الاتصال، ثم أعطِ المشاركين الرمز <strong>${esc(live.code || '')}</strong>.</p>
        </div>`;
    } else {
      $('#liveParticipants').innerHTML = participants.map((participant) => {
        const isDone = Boolean(participant.submitted);
        const status = isDone
          ? isolate(`${participant.score} / ${live.total}`)
          : (phase === 'running' ? `${isolate(`${participant.answered} / ${live.total}`)}` : 'في الانتظار');
        const stateLabel = isDone ? 'سلّم النسخة' : (phase === 'running' ? 'يجيب الآن' : 'انضمّ');
        return `
          <button class="participant-row${isDone ? ' is-done' : ''}" type="button" data-participant="${esc(participant.name)}"${isDone ? '' : ' disabled'}>
            <span class="participant-avatar" aria-hidden="true">${esc(initial(participant.name))}</span>
            <span class="participant-name">
              <strong>${esc(participant.name)}</strong>
              <small>${esc(stateLabel)}</small>
            </span>
            <span class="participant-answered">${status}</span>
            <span class="participant-dot${participant.online ? ' is-online' : ''}" aria-hidden="true"></span>
          </button>`;
      }).join('');
    }

    renderBoard(participants);
  }

  function initial(name) {
    const text = String(name || '').trim();
    return text ? Array.from(text)[0] : '؟';
  }

  function renderBoard(participants) {
    const host = $('#liveResults');
    const submitted = participants.filter((participant) => participant.submitted);
    if (!submitted.length) {
      host.innerHTML = `
        <div class="board-empty">
          <strong>لا نتائج بعد</strong>
          <p>${live.phase === 'lobby' ? 'تبدأ النتائج بعد إطلاق الأسئلة.' : 'ستظهر النسخ هنا فور تسليمها.'}</p>
        </div>`;
      return;
    }

    const sorted = submitted.slice().sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      return left.timeMs - right.timeMs;
    });

    host.innerHTML = sorted.map((participant, index) => {
      const percent = live.total ? Math.round((participant.score / live.total) * 100) : 0;
      return `
        <button class="board-row" type="button" data-participant="${esc(participant.name)}">
          <span class="board-rank">${isolate(String(index + 1))}</span>
          <span class="board-name">
            <strong>${esc(participant.name)}</strong>
            <small>${formatTime(participant.timeMs)}</small>
          </span>
          <span class="board-bar"><i style="width:${percent}%"></i></span>
          <span class="board-score">${isolate(`${participant.score} / ${live.total}`)}</span>
        </button>`;
    }).join('');
  }

  /* ------------------------------------------------------------------ */
  /* أوامر الجلسة                                                       */
  /* ------------------------------------------------------------------ */

  function startExam() {
    if (!bridge || busy) return;
    const participants = live && Array.isArray(live.participants) ? live.participants : [];
    if (!participants.length) {
      toast('انتظر انضمام مشارك واحد على الأقل.');
      return;
    }
    if (!window.confirm(`إطلاق الأسئلة الآن لـ ${participants.length} مشاركًا؟ سيبدأ المؤقّت للجميع في اللحظة نفسها.`)) return;

    busy = true;
    let response;
    try {
      response = JSON.parse(bridge.startExam());
    } catch (error) {
      response = { ok: false, error: 'bridge' };
    }
    busy = false;

    if (!response.ok) {
      toast(response.error === 'empty' ? 'لا يوجد مشاركون.' : 'تعذّر بدء الجلسة.');
      return;
    }
    poll();
  }

  function finishExam() {
    if (!bridge || busy) return;
    if (!window.confirm('إنهاء الجلسة الآن؟ ستُحتسب الإجابات المسجّلة، ويُغلق استقبال الإجابات الجديدة.')) return;
    busy = true;
    try {
      JSON.parse(bridge.finish());
    } catch (error) {
      /* ignoré : la synchronisation suivante corrigera l'état */
    }
    busy = false;
    poll();
  }

  function stopSession() {
    if (!bridge || busy) return;
    const phase = live ? live.phase : 'idle';
    if (phase === 'ended' || phase === 'stopped') {
      busy = true;
      try {
        JSON.parse(bridge.stop());
      } catch (error) {
        /* ignoré */
      }
      busy = false;
      live = null;
      showSetup();
      refreshInfo();
      return;
    }

    if (!window.confirm('إيقاف الجلسة؟ ستنقطع اتصالات المشاركين وتُفقد الجلسة الحالية.')) return;
    busy = true;
    try {
      JSON.parse(bridge.stop());
    } catch (error) {
      /* ignoré */
    }
    busy = false;
    live = null;
    showSetup();
    refreshInfo();
  }

  /* ------------------------------------------------------------------ */
  /* نسخة المشارك                                                       */
  /* ------------------------------------------------------------------ */

  function openDetail(name) {
    if (!bridge) return;
    let data = resultsCache;
    if (!data) {
      try {
        data = JSON.parse(bridge.results());
        resultsCache = data;
      } catch (error) {
        toast('تعذّر تحميل النسخة.');
        return;
      }
    }

    const participant = (data.participants || []).find((item) => item.name === name);
    if (!participant) {
      toast('لم يُعثر على نسخة هذا المشارك.');
      return;
    }

    detailName = name;
    const questions = data.questions || [];
    const order = participant.order || [];
    const answers = participant.answers || [];

    const rows = order.map((questionIndex, position) => {
      const question = questions[questionIndex];
      if (!question) return '';
      const choice = answers[position];
      const given = choice >= 0 ? question.options[choice] : null;
      const ok = choice === question.answer;
      return `
        <details class="detail-item ${ok ? 'is-ok' : 'is-no'}">
          <summary>
            <span class="detail-mark">${ok ? '✓' : '×'}</span>
            <span class="detail-question"><small>${isolate(`السؤال ${position + 1}`)}</small>${esc(question.q)}</span>
          </summary>
          <div class="detail-body">
            <p class="detail-given ${ok ? 'ok' : 'bad'}">إجابة المشارك: <strong>${given ? esc(given) : 'دون إجابة'}</strong></p>
            ${ok ? '' : `<p class="detail-good">الإجابة الصحيحة: <strong>${esc(question.options[question.answer])}</strong></p>`}
            <p class="detail-exp">${esc(question.exp || '')}</p>
            <small>${esc(question.source || '')} · ${esc(CATEGORIES[question.cat] ? CATEGORIES[question.cat].label : '')}</small>
          </div>
        </details>`;
    }).join('');

    $('#detailContent').innerHTML = `
      <span class="modal-eyebrow">نسخة المشارك</span>
      <h2 id="detailTitle">${esc(participant.name)}</h2>
      <div class="detail-stats">
        <div><span>النتيجة</span><strong>${isolate(`${participant.score} / ${participant.total}`)}</strong></div>
        <div><span>النسبة</span><strong>${isolate(`${participant.percent}%`)}</strong></div>
        <div><span>الوقت</span><strong>${formatTime(participant.timeMs)}</strong></div>
        <div><span>المُجاب</span><strong>${isolate(`${participant.answered} / ${participant.total}`)}</strong></div>
      </div>
      <div class="detail-list">${rows || '<p class="detail-empty">لا توجد إجابات مسجّلة.</p>'}</div>`;

    $('#sessionDetail').hidden = false;
    document.body.classList.add('no-scroll');
  }

  function closeDetail() {
    $('#sessionDetail').hidden = true;
    document.body.classList.remove('no-scroll');
    detailName = null;
  }

  /* ------------------------------------------------------------------ */
  /* الأحداث                                                            */
  /* ------------------------------------------------------------------ */

  function bind() {
    $('#startSessionBtn').addEventListener('click', startSession);
    $('#startExamBtn').addEventListener('click', startExam);
    $('#finishExamBtn').addEventListener('click', finishExam);
    $('#stopSessionBtn').addEventListener('click', stopSession);

    $('#sessionCatGrid').addEventListener('click', (event) => {
      const card = event.target.closest('[data-session-cat]');
      if (!card) return;
      config.cat = card.dataset.sessionCat;
      if (config.cat !== 'all' && !CATEGORIES[config.cat]) config.cat = 'all';
      saveConfig();
      renderSetup();
    });

    $('#sessionCountPicker').addEventListener('click', (event) => {
      const button = event.target.closest('.count-btn');
      if (!button) return;
      config.count = button.dataset.count === 'all' ? 'all' : Number(button.dataset.count);
      saveConfig();
      renderSetup();
    });

    $('#sessionLevelPicker').addEventListener('click', (event) => {
      const button = event.target.closest('.count-btn');
      if (!button) return;
      config.level = button.dataset.level === 'all' ? 'all' : 'advanced';
      saveConfig();
      renderSetup();
    });

    $('#sessionDurationPicker').addEventListener('click', (event) => {
      const button = event.target.closest('.count-btn');
      if (!button) return;
      config.duration = Number(button.dataset.duration);
      saveConfig();
      renderSetup();
    });

    $('#sessionTitleInput').addEventListener('input', (event) => {
      config.title = event.target.value.slice(0, 60);
      saveConfig();
    });

    $('#sessionShuffleToggle').addEventListener('change', (event) => {
      config.shuffle = event.target.checked;
      saveConfig();
    });

    $('#copyCodeBtn').addEventListener('click', () => {
      if (live && live.code) copyText(live.code, 'تم نسخ الرمز.');
    });

    $('#liveIps').addEventListener('click', () => {
      if (live && live.ips && live.ips.length) copyText(`${live.ips[0]}:${live.port || 8765}`, 'تم نسخ عنوان المدرب.');
    });

    const copyIpBtn = $('#copyIpBtn');
    if (copyIpBtn) {
      copyIpBtn.addEventListener('click', () => {
        const ip = $('#sessionIps').dataset.ip;
        if (ip) copyText(`${ip}:8765`, 'تم نسخ عنوان المدرب.');
        else toast('لم يُعثر على عنوان. فعّل نقطة الاتصال أولًا.');
      });
    }

    $('#liveParticipants').addEventListener('click', (event) => {
      const row = event.target.closest('[data-participant]');
      if (row) openDetail(row.dataset.participant);
    });

    $('#liveResults').addEventListener('click', (event) => {
      const row = event.target.closest('[data-participant]');
      if (row) openDetail(row.dataset.participant);
    });

    $('#detailCloseBtn').addEventListener('click', closeDetail);
    $('#sessionDetail').addEventListener('click', (event) => {
      if (event.target === $('#sessionDetail')) closeDetail();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !$('#sessionDetail').hidden) closeDetail();
    });

    window.addEventListener('hashchange', () => {
      if (currentView() !== 'sessions') stopPolling();
    });

    document.addEventListener('ringcatalogchange', () => {
      if (config.cat !== 'all' && !CATEGORIES[config.cat]) {
        config.cat = 'all';
        saveConfig();
      }
      if (currentView() === 'sessions' && !$('#sessionSetup').hidden) renderSetup();
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        stopPolling();
      } else if (currentView() === 'sessions' && live && (live.phase === 'lobby' || live.phase === 'running')) {
        poll();
      }
    });
  }

  function currentView() {
    return (location.hash || '#accueil').replace(/^#/, '').split('/')[0] || 'accueil';
  }

  function copyText(text, message) {
    const finish = () => toast(message);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(String(text)).then(finish, () => fallbackCopy(text, finish));
      return;
    }
    fallbackCopy(text, finish);
  }

  function fallbackCopy(text, done) {
    try {
      const area = document.createElement('textarea');
      area.value = String(text);
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      document.body.removeChild(area);
      done();
    } catch (error) {
      toast(String(text));
    }
  }

  function toast(message) {
    const element = $('#toast');
    if (!element) return;
    element.textContent = message;
    element.classList.add('is-visible');
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => element.classList.remove('is-visible'), 2600);
  }

  function shuffle(items) {
    const list = items.slice();
    for (let index = list.length - 1; index > 0; index -= 1) {
      const swap = Math.floor(Math.random() * (index + 1));
      [list[index], list[swap]] = [list[swap], list[index]];
    }
    return list;
  }

  // يرتّب الاختيارات عشوائيًا ويُعيد ضبط رقم الإجابة الصحيحة. ضروري لأن
  // الاختيار الصحيح كان في الغالب الأول أو الثاني في ملفات الدروس.
  function withShuffledOptions(question) {
    if (!Array.isArray(question.options) || question.options.length < 2) return question;
    const order = shuffle(question.options.map((option, index) => index));
    return {
      ...question,
      options: order.map((index) => question.options[index]),
      answer: order.indexOf(question.answer)
    };
  }

  /* ------------------------------------------------------------------ */
  /* محاكاة للعرض على الحاسوب (?mock=1)                                 */
  /* ------------------------------------------------------------------ */

  function createMockBridge() {
    let state = null;
    let questions = [];
    let tick = null;
    const names = ['أمين الحلبي', 'سارة بن علي', 'يوسف مراد', 'ليلى الزهراني', 'كريم ناصر'];

    function stateJson() {
      if (state && state.phase === 'running') {
        state.remainingMs = Math.max(0, state.endsAt - Date.now());
        const elapsed = Date.now() - state.startedAt;
        state.participants.forEach((participant, index) => {
          if (!participant.submitted && elapsed > 9000 + index * 7000) {
            participant.submitted = true;
            participant.answered = state.total;
            participant.score = Math.max(3, state.total - index * 2 - (index === 2 ? 3 : 0));
            participant.timeMs = Math.min(state.endsAt, Date.now()) - state.startedAt;
          }
        });
        if (Date.now() >= state.endsAt) state.phase = 'ended';
      }
      return JSON.stringify(state);
    }

    return {
      info: () => JSON.stringify({ ok: true, port: 8765, ips: ['192.168.43.1'] }),
      start: (configJson, questionsJson) => {
        const config = JSON.parse(configJson);
        questions = JSON.parse(questionsJson);
        const now = Date.now();
        state = {
          ok: true,
          active: true,
          phase: 'lobby',
          code: '4821',
          port: 8765,
          ips: ['192.168.43.1'],
          title: config.title,
          total: questions.length,
          durationSec: config.durationSec,
          startedAt: 0,
          endsAt: 0,
          remainingMs: config.durationSec * 1000,
          participants: []
        };
        if (tick) clearInterval(tick);
        tick = setInterval(() => {
          if (state && state.phase === 'lobby' && state.participants.length < 4) {
            const name = names[state.participants.length];
            state.participants.push({ name, status: 'lobby', answered: 0, submitted: false, score: 0, timeMs: 0, online: true });
          }
        }, 2200);
        setTimeout(() => {
          if (state && state.phase === 'lobby') state.participants.push({ name: names[4], status: 'lobby', answered: 0, submitted: false, score: 0, timeMs: 0, online: true });
        }, 9800);
        return JSON.stringify({ ok: true, code: '4821', port: 8765, ips: ['192.168.43.1'], total: questions.length, durationSec: config.durationSec });
      },
      state: stateJson,
      startExam: () => {
        if (!state || state.phase !== 'lobby') return JSON.stringify({ ok: false, error: 'phase' });
        state.phase = 'running';
        state.startedAt = Date.now();
        state.endsAt = state.startedAt + state.durationSec * 1000;
        return JSON.stringify({ ok: true });
      },
      finish: () => {
        if (state && state.phase === 'running') {
          state.endsAt = Date.now();
          state.phase = 'ended';
          state.participants.forEach((participant, index) => {
            if (!participant.submitted) {
              participant.submitted = true;
              participant.answered = state.total;
              participant.score = Math.max(2, state.total - index - 1);
              participant.timeMs = Date.now() - state.startedAt;
            }
          });
        }
        return JSON.stringify({ ok: true });
      },
      stop: () => {
        if (tick) clearInterval(tick);
        if (state) state.active = false;
        return JSON.stringify({ ok: true });
      },
      results: () => {
        const base = state || { total: 0, participants: [], questions: [] };
        return JSON.stringify({
          ok: true,
          phase: base.phase,
          title: base.title,
          total: base.total,
          questions: questions.map((question) => ({ ...question })),
          participants: (base.participants || []).map((participant, personIndex) => {
            const order = questions.map((question, index) => index);
            const answers = order.map((questionIndex, position) => {
              if (!participant.submitted) return -1;
              return (position + personIndex) % 4 === 0 ? -1 : (questions[questionIndex].answer + (position % 3 === 0 ? 1 : 0)) % 4;
            });
            return {
              name: participant.name,
              submitted: participant.submitted,
              score: participant.score,
              total: base.total,
              percent: base.total ? Math.round(participant.score * 100 / base.total) : 0,
              timeMs: participant.timeMs,
              answered: participant.answered,
              order,
              answers
            };
          })
        });
      }
    };
  }

  /* ------------------------------------------------------------------ */
  /* الانطلاق                                                           */
  /* ------------------------------------------------------------------ */

  bind();
  render();

  window.RingSessions = { render };
})();
