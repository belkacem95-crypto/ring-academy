/* =========================================================
   أكاديمية الحلبة — محرّك التطبيق
   البيانات: js/courses/*.js عبر js/catalog.js · دون أيّ اعتماد خارجي.
   ========================================================= */

(() => {
  'use strict';

  const STORE_KEY = 'ringAcademy.v1';
  const DEFAULT_STATE = () => ({
    modulesRead: {},
    history: [],
    qstats: {},
    best: 0,
    lastWrong: []
  });

  let state = loadState();
  let selectedMode = 'training';
  let selectedCat = 'all';
  let selectedCount = 20;
  let session = null;
  let lastResults = null;
  let lastConfig = null;
  let toastTimer = null;

  /* ---------------------------------------------------------
     أدوات مساعدة
     --------------------------------------------------------- */

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));

  function shuffle(items) {
    const list = items.slice();
    for (let i = list.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [list[i], list[j]] = [list[j], list[i]];
    }
    return list;
  }

  // Mélange l'ordre des réponses à chaque session : la bonne réponse ne peut
  // plus être devinée par sa position (elle était presque toujours la 1re ou
  // la 2e dans les fichiers de cours).
  function withShuffledOptions(question) {
    if (!Array.isArray(question.options) || question.options.length < 2) return question;
    const order = shuffle(question.options.map((option, index) => index));
    return {
      ...question,
      options: order.map((index) => question.options[index]),
      answer: order.indexOf(question.answer)
    };
  }

  function loadState() {
    const base = DEFAULT_STATE();
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return base;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object') return base;
      return {
        modulesRead: parsed.modulesRead && typeof parsed.modulesRead === 'object' ? parsed.modulesRead : {},
        history: Array.isArray(parsed.history) ? parsed.history.slice(0, 60) : [],
        qstats: parsed.qstats && typeof parsed.qstats === 'object' ? parsed.qstats : {},
        best: Number.isFinite(Number(parsed.best)) ? Number(parsed.best) : 0,
        lastWrong: Array.isArray(parsed.lastWrong) ? parsed.lastWrong : []
      };
    } catch (error) {
      return base;
    }
  }

  function saveState() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(state));
    } catch (error) {
      /* قد يكون localStorage محظورًا: يواصل التطبيق العمل في الذاكرة. */
    }
  }

  function resetState() {
    state = DEFAULT_STATE();
    saveState();
  }

  function questionCount(cat) {
    if (cat === 'all') return QUESTIONS.length;
    return QUESTIONS.filter((question) => question.cat === cat).length;
  }

  function questionsLabel(count) {
    if (count === 1) return 'سؤال واحد';
    if (count === 2) return 'سؤالان';
    if (count >= 3 && count <= 10) return `${count} أسئلة`;
    return `${count} سؤالًا`;
  }

  function modulesLabel(count) {
    if (count === 1) return 'وحدة واحدة';
    if (count === 2) return 'وحدتان';
    if (count >= 3 && count <= 10) return `${count} وحدات`;
    return `${count} وحدة`;
  }

  function answersLabel(count) {
    if (count === 1) return 'إجابة واحدة';
    if (count === 2) return 'إجابتان';
    if (count >= 3 && count <= 10) return `${count} إجابات`;
    return `${count} إجابة`;
  }

  function sessionsLabel(count) {
    if (count === 1) return 'جلسة واحدة';
    if (count === 2) return 'جلستان';
    if (count >= 3 && count <= 10) return `${count} جلسات`;
    return `${count} جلسة`;
  }

  function categoryLabel(cat) {
    return cat === 'all' ? 'كل الأسئلة' : (CATEGORIES[cat] ? CATEGORIES[cat].label : 'كل الأسئلة');
  }

  function isSignalCategory(cat) {
    const category = CATEGORIES[cat];
    return Boolean(category && category.icon === 'hand');
  }

  function refreshCounts() {
    const counts = {
      questions: QUESTIONS.length,
      modules: MODULES.length,
      signals: SIGNALS.length,
      themes: Object.keys(CATEGORIES).length,
      courses: window.RingCatalog ? RingCatalog.counts().active : 1
    };
    Object.keys(counts).forEach((key) => {
      $$(`[data-count-${key}]`).forEach((element) => {
        element.textContent = counts[key];
      });
    });
  }

  function bestPercent() {
    const fromHistory = state.history.reduce((max, item) => Math.max(max, Number(item.pct) || 0), 0);
    return Math.max(Number(state.best) || 0, fromHistory);
  }

  function seenQuestions() {
    return QUESTIONS.filter((question) => {
      const stats = state.qstats[question.id];
      return stats && Number(stats.seen) > 0;
    }).length;
  }

  function readModules() {
    return MODULES.filter((module) => state.modulesRead[module.id]).length;
  }

  function overallProgress() {
    const total = MODULES.length + QUESTIONS.length;
    return Math.round(((readModules() + seenQuestions()) / total) * 100);
  }

  function categoryStats(cat) {
    const questions = QUESTIONS.filter((question) => question.cat === cat);
    let seen = 0;
    let correct = 0;
    questions.forEach((question) => {
      const stats = state.qstats[question.id];
      if (stats && Number(stats.seen) > 0) {
        seen += Number(stats.seen);
        correct += Number(stats.correct) || 0;
      }
    });
    return {
      total: questions.length,
      seen,
      correct,
      pct: seen ? Math.round((correct / seen) * 100) : 0
    };
  }

  function formatDuration(ms) {
    const total = Math.max(0, Math.round((Number(ms) || 0) / 1000));
    const minutes = Math.floor(total / 60);
    return `\u2066${minutes}:${String(total % 60).padStart(2, '0')}\u2069`;
  }

  function formatDate(iso) {
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return '';
    return `${date.toLocaleDateString('ar-MA-u-nu-latn', { day: '2-digit', month: 'short' })} · ${date.toLocaleTimeString('ar-MA-u-nu-latn', { hour: '2-digit', minute: '2-digit' })}`;
  }

  function currentView() {
    return (location.hash || '#accueil').replace(/^#/, '').split('/')[0] || 'accueil';
  }

  function currentQuestion() {
    if (!session) return null;
    return session.questions[session.index] || null;
  }

  /* ---------------------------------------------------------
     أيقونات مضمّنة
     --------------------------------------------------------- */

  const ICONS = {
    whistle: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M13.5 10V7.6A1.6 1.6 0 0 0 11.9 6H9.2A4.2 4.2 0 1 0 13.4 12.2h.1V10Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M13.5 7.5H21v3h-7.5M17 14h3M15 17.5h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3.5 20 6v5.5c0 4.3-3.4 7.7-8 9.3-4.6-1.6-8-5-8-9.3V6l8-2.5Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="m8.8 12 2.2 2.2 4.4-4.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    target: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="4.5" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/></svg>',
    alert: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 4 21 20H3L12 4Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 9v5M12 17.4v.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    trophy: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 4h8v5a4 4 0 0 1-8 0V4Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M8 6H5.5v1.5A3.5 3.5 0 0 0 9 11M16 6h2.5v1.5A3.5 3.5 0 0 1 15 11M12 13v4M9 20h6M10 17h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    hand: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M9 12V5.8a1.5 1.5 0 0 1 3 0V11m0-6.2a1.5 1.5 0 0 1 3 0V11m0-4.2a1.5 1.5 0 0 1 3 0V13c0 4.4-2.7 7-6.8 7S6 17.3 6 13.5V9.8a1.5 1.5 0 0 1 3 0V12" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    grid: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="4" width="6.5" height="6.5" rx="1.2" stroke="currentColor" stroke-width="1.6"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.2" stroke="currentColor" stroke-width="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.2" stroke="currentColor" stroke-width="1.6"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.2" stroke="currentColor" stroke-width="1.6"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12.5 9.5 17 19 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  /* ---------------------------------------------------------
     الرئيسية
     --------------------------------------------------------- */

  function moduleCard(module) {
    const read = Boolean(state.modulesRead[module.id]);
    return `
      <a class="module-card${read ? ' is-read' : ''}" href="#lecon/${esc(module.id)}">
        <div class="module-cover">
          <img src="${esc(module.img)}" alt="${esc(module.title)}">
          <span class="module-read">مقروءة</span>
          <span class="module-number">${esc(module.number)}</span>
        </div>
        <div class="module-body">
          <span class="module-course">${esc(module.courseShort || '')}</span>
          <h3>${esc(module.title)}</h3>
          <p>${esc(module.subtitle)}</p>
          <div class="module-foot">
            <span>${esc(module.duration)} · ${questionsLabel(questionCount(module.id))}</span>
            <span>افتح ←</span>
          </div>
        </div>
      </a>`;
  }

  function signalPreview(signal) {
    const src = signal.src || `assets/img/${signal.file}`;
    return `
      <button class="signal-preview" type="button"
        data-lightbox="${esc(src)}"
        data-caption="${esc(signal.name)} — ${esc(signal.desc)}">
        <img src="${esc(src)}" alt="${esc(signal.name)}">
        <strong>${esc(signal.name)}</strong>
      </button>`;
  }

  function renderHome() {
    const seen = seenQuestions();
    const read = readModules();
    const best = bestPercent();
    const progress = overallProgress();
    const hasHistory = state.history.length > 0;

    $('#homeBestScore').textContent = hasHistory ? `${best}%` : '—';
    $('#homeScoreOrbit').style.setProperty('--pct', hasHistory ? best : 0);
    $('#homeAnswered').textContent = `\u2067${seen} من ${QUESTIONS.length} سؤالًا\u2069`;
    $('#homeModules').textContent = `\u2067${read} من ${MODULES.length} وحدات مقروءة\u2069`;
    $('#homeProgressBar').style.width = `${progress}%`;

    const pill = $('#homeBestPill');
    pill.textContent = !hasHistory ? 'جديد' : (best >= 80 ? 'في المستوى' : (best >= 50 ? 'في تقدّم' : 'يحتاج مراجعة'));

    $('#homeModuleGrid').innerHTML = MODULES.map(moduleCard).join('');
    $('#homeSignals').innerHTML = SIGNALS.map(signalPreview).join('');
  }

  /* ---------------------------------------------------------
     البرنامج
     --------------------------------------------------------- */

  function updateCourseMeter() {
    const read = readModules();
    const pct = Math.round((read / MODULES.length) * 100);
    $('#courseReadCount').textContent = `\u2067${read} من ${MODULES.length}\u2069`;
    $('#courseReadBar').style.width = `${pct}%`;

    let note = 'ابدأ بالوحدة 1.';
    if (read === MODULES.length) note = 'أتممت البرنامج. حان وقت الاختبار!';
    else if (read > 0) note = `بقيت ${modulesLabel(MODULES.length - read)} للقراءة.`;
    $('#courseReadNote').textContent = note;
  }

  function renderCourse() {
    updateCourseMeter();
    $('#courseList').innerHTML = MODULES.map((module) => {
      const read = Boolean(state.modulesRead[module.id]);
      return `
        <a class="course-item" href="#lecon/${esc(module.id)}">
          <div class="course-thumb">
            <img src="${esc(module.img)}" alt="${esc(module.title)}">
            <span>${esc(module.number)}</span>
          </div>
          <div class="course-info">
            <span class="module-course">${esc(module.courseShort || '')}</span>
            <h3>${esc(module.title)}${read ? '<span class="read-dot" aria-label="وحدة مقروءة"></span>' : ''}</h3>
            <p>${esc(module.subtitle)} ${esc(module.intro)}</p>
            <div class="course-info-meta">
              <span>${esc(module.duration)}</span>
              <span>${questionsLabel(questionCount(module.id))}</span>
              <span>${read ? 'مقروءة' : 'للقراءة'}</span>
            </div>
          </div>
          <div class="course-cta">
            <span>${read ? 'إعادة القراءة' : 'ابدأ'}</span>
            <span class="arrow-circle" aria-hidden="true">←</span>
          </div>
        </a>`;
    }).join('');
  }

  function signalCard(signal) {
    const src = signal.src || `assets/img/${signal.file}`;
    return `
      <button class="signal-card" type="button"
        data-lightbox="${esc(src)}"
        data-caption="${esc(signal.name)} — ${esc(signal.desc)}">
        <img src="${esc(src)}" alt="${esc(signal.name)}">
        <strong>${esc(signal.name)}</strong>
        <small>${esc(signal.desc)}</small>
      </button>`;
  }

  function renderLesson(id) {
    const module = MODULES.find((item) => item.id === id);
    if (!module) {
      location.replace('#cours');
      return;
    }

    const read = Boolean(state.modulesRead[module.id]);
    const index = MODULES.indexOf(module);
    const previous = MODULES[index - 1];
    const next = MODULES[index + 1];

    const commands = module.commands ? `
      <div class="commands-card">
        <h3>الأوامر الأساسية</h3>
        ${module.commands.map(([command, meaning]) => `
          <div class="command-row">
            <strong>${esc(command)}</strong>
            <span>${esc(meaning)}</span>
          </div>`).join('')}
      </div>` : '';

    const signals = module.key === 'signaux' ? `
      <div class="lesson-signals">
        <h2>${SIGNALS.length} إشارة بالصور</h2>
        <p>اضغط على إشارة لتكبيرها.</p>
        <div class="signal-grid">${SIGNALS.map(signalCard).join('')}</div>
      </div>` : '';

    $('#lessonContent').innerHTML = `
      <a class="icon-text-btn" href="#cours" data-nav="cours">
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M12 5l-5 5 5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
        البرنامج كامل
      </a>

      <div class="lesson-hero" style="margin-top:14px">
        <img src="${esc(module.img)}" alt="${esc(module.title)}">
        <div class="lesson-hero-body">
          <span class="lesson-num">${esc(module.courseShort || '')} · الوحدة ${esc(module.number)}</span>
          <h1>${esc(module.title)}</h1>
          <p>${esc(module.intro)}</p>
          <div class="lesson-meta">
            <span>${esc(module.duration)}</span>
            <span>${questionsLabel(questionCount(module.id))}</span>
            <span>${read ? 'مقروءة' : 'للقراءة'}</span>
          </div>
        </div>
      </div>

      <div class="lesson-grid">
        <div class="lesson-main">
          <h2>ما يجب حفظه</h2>
          <ul class="lesson-points">
            ${module.points.map((point, pointIndex) => `
              <li>
                <span class="num">${pointIndex + 1}</span>
                <span>${esc(point)}</span>
              </li>`).join('')}
          </ul>
          ${signals}
        </div>

        <aside class="lesson-side">
          <div class="memo-card">
            <span>الخلاصة</span>
            <p>${esc(module.memo)}</p>
          </div>
          <div class="side-actions">
            <a class="btn btn-primary" href="#quiz" data-nav="quiz" data-quiz-cat="${esc(module.id)}">اختبار الوحدة ←</a>
            <button class="read-toggle${read ? ' is-read' : ''}" type="button" data-toggle-read="${esc(module.id)}">
              ${ICONS.check}
              ${read ? 'وحدة مقروءة — إزالة' : 'تعليمها كمقروءة'}
            </button>
          </div>
          ${commands}
        </aside>
      </div>

      <nav class="lesson-nav" aria-label="التنقّل بين الوحدات">
        ${previous ? `
          <a href="#lecon/${esc(previous.id)}">
            <small>السابق</small>
            <strong>→ ${esc(previous.title)}</strong>
          </a>` : ''}
        ${next ? `
          <a class="next" href="#lecon/${esc(next.id)}">
            <small>التالي</small>
            <strong>${esc(next.title)} ←</strong>
          </a>` : ''}
      </nav>`;
  }

  /* ---------------------------------------------------------
     ضبط الاختبار
     --------------------------------------------------------- */

  function availableCount(cat) {
    return cat === 'all' ? QUESTIONS.length : QUESTIONS.filter((question) => question.cat === cat).length;
  }

  function effectiveCount() {
    const available = availableCount(selectedCat);
    if (selectedCount === 'all') return available;
    return Math.min(Number(selectedCount) || 0, available);
  }

  function renderCategoryGrid() {
    if (selectedCat !== 'all' && !CATEGORIES[selectedCat]) selectedCat = 'all';

    const allCard = `
      <button class="cat-card cat-card-all${selectedCat === 'all' ? ' is-selected' : ''}" type="button" data-cat="all">
        <span class="cat-icon" style="--accent:#e63946">${ICONS.grid}</span>
        <span class="cat-text">
          <strong>كل الأسئلة</strong>
          <small>${QUESTIONS.length} سؤالًا · ${Object.keys(CATEGORIES).length} محاور</small>
        </span>
        <span class="cat-check" aria-hidden="true"></span>
      </button>`;

    const categoryCards = Object.entries(CATEGORIES).map(([key, category]) => {
      const count = questionCount(key);
      return `
        <button class="cat-card${selectedCat === key ? ' is-selected' : ''}" type="button" data-cat="${esc(key)}">
          <span class="cat-icon" style="--accent:${esc(category.color)}">${ICONS[category.icon] || ICONS.grid}</span>
          <span class="cat-text">
            <strong>${esc(category.label)}</strong>
            <small>${questionsLabel(count)}</small>
          </span>
          <span class="cat-check" aria-hidden="true"></span>
        </button>`;
    }).join('');

    $('#categoryGrid').innerHTML = allCard + categoryCards;
    syncSetupUI();
  }

  function syncSetupUI() {
    $$('#modeGrid .mode-card').forEach((button) => {
      button.classList.toggle('is-selected', button.dataset.mode === selectedMode);
    });
    $$('#categoryGrid .cat-card').forEach((button) => {
      button.classList.toggle('is-selected', button.dataset.cat === selectedCat);
    });
    $$('.count-btn').forEach((button) => {
      button.classList.toggle('is-selected', String(selectedCount) === button.dataset.count);
    });

    const count = effectiveCount();
    const modeLabel = selectedMode === 'exam' ? 'امتحان' : 'تدريب';
    const shuffled = $('#shuffleToggle').checked ? ' · مخلوط' : '';
    $('#launchSummary').textContent = `${questionsLabel(count)} · ${categoryLabel(selectedCat)} · ${modeLabel}${shuffled}`;
    $('#startQuizBtn').disabled = count === 0;
  }

  function launchFromConfig(config) {
    const pool = config.cat === 'all'
      ? QUESTIONS.slice()
      : QUESTIONS.filter((question) => question.cat === config.cat);
    const ordered = config.shuffle ? shuffle(pool) : pool;
    const requested = config.count === 'all' ? ordered.length : Number(config.count) || 0;
    const questions = ordered.slice(0, Math.min(requested, ordered.length));

    if (!questions.length) {
      toast('لا توجد أسئلة متاحة في هذا المحور.');
      return;
    }

    startSession({
      mode: config.mode,
      cat: config.cat,
      count: config.count,
      shuffle: config.shuffle,
      questions
    });
  }

  function startSession(incoming) {
    if (session) stopTimer();

    const label = incoming.label || categoryLabel(incoming.cat);
    session = {
      mode: incoming.mode === 'exam' ? 'exam' : 'training',
      cat: incoming.cat,
      count: incoming.count,
      shuffle: Boolean(incoming.shuffle),
      label,
      questions: incoming.questions.map(withShuffledOptions),
      index: 0,
      answers: new Array(incoming.questions.length).fill(null),
      selected: null,
      locked: false,
      elapsedMs: 0,
      active: false,
      tickBase: 0,
      timerId: null,
      finished: false,
      startedAt: Date.now()
    };

    lastConfig = {
      mode: session.mode,
      cat: session.cat,
      count: incoming.count,
      shuffle: Boolean(incoming.shuffle)
    };

    $('#quizSetup').hidden = true;
    $('#quizPlay').hidden = false;
    $('#view-quiz').classList.add('is-playing');
    renderQuestion();
    window.scrollTo({ top: 0, behavior: 'auto' });

    if (currentView() === 'quiz') startTimer();
    else location.hash = '#quiz';
  }

  function renderQuiz() {
    $('#view-quiz').classList.toggle('is-playing', Boolean(session && !session.finished));
    if (session && !session.finished) {
      $('#quizSetup').hidden = true;
      $('#quizPlay').hidden = false;
      renderQuestion();
    } else {
      $('#quizPlay').hidden = true;
      $('#quizSetup').hidden = false;
      renderCategoryGrid();
    }
  }

  /* ---------------------------------------------------------
     سير السؤال
     --------------------------------------------------------- */

  function renderQuestion() {
    if (!session) return;
    const question = currentQuestion();
    if (!question) return;

    const isSignal = isSignalCategory(question.cat);
    const hasImage = Boolean(question.img);
    const media = $('#qMedia');
    media.hidden = !hasImage;
    media.classList.toggle('is-portrait', isSignal);
    media.classList.toggle('is-signal', isSignal);
    media.classList.toggle('fit-contain', isSignal || /(ring-design|scoring-paper)/.test(question.img || ''));

    const image = $('#qImage');
    if (hasImage) {
      image.src = question.img;
      image.alt = question.alt || question.q;
    } else {
      image.removeAttribute('src');
      image.alt = '';
    }
    $('#qCaption').textContent = isSignal ? 'إشارة الحكم' : (CATEGORIES[question.cat] ? CATEGORIES[question.cat].short : '');
    const courseLink = $('#feedbackCourseBtn');
    if (courseLink) courseLink.hidden = !MODULES.some((module) => module.id === question.cat);

    $('#qNumber').textContent = `السؤال ${String(session.index + 1).padStart(2, '0')}`;
    $('#qDifficulty').textContent = question.level;
    $('#qTitle').textContent = question.q;

    $('#qOptions').innerHTML = question.options.map((option, index) => `
      <button class="option" type="button" data-index="${index}">
        <span class="option-letter">${'أبجد'[index] || String(index + 1)}</span>
        <span>${esc(option)}</span>
      </button>`).join('');

    const feedback = $('#qFeedback');
    feedback.hidden = true;
    feedback.className = 'feedback';

    const answer = session.answers[session.index];
    const nextButton = $('#nextQuestionBtn');
    const lastQuestion = session.index === session.questions.length - 1;

    if (answer && session.mode === 'training') {
      session.selected = answer.choice;
      session.locked = true;
      paintOptions(answer.choice, true);
      showFeedback(question, answer.correct, answer.choice);
      nextButton.disabled = false;
    } else {
      session.locked = false;
      paintOptions(session.selected, false);
      nextButton.disabled = session.mode === 'exam' ? session.selected === null : true;
    }

    nextButton.innerHTML = lastQuestion
      ? 'اعرض نتائجي <span aria-hidden="true">←</span>'
      : 'التالي <span aria-hidden="true">←</span>';

    $('#playCategory').textContent = session.label;
    $('#playCount').textContent = `\u2067${session.index + 1} من ${session.questions.length}\u2069`;
    $('#playProgressBar').style.width = `${((session.index + 1) / session.questions.length) * 100}%`;
    updateTimer();
  }

  function paintOptions(choice, locked) {
    const question = currentQuestion();
    if (!question) return;

    $$('#qOptions .option').forEach((button, index) => {
      button.classList.remove('is-selected', 'is-correct', 'is-wrong', 'is-dim');
      button.disabled = Boolean(locked);

      if (locked && session.mode === 'training') {
        if (index === question.answer) button.classList.add('is-correct');
        else if (index === choice) button.classList.add('is-wrong');
        else button.classList.add('is-dim');
        return;
      }

      if (choice !== null && choice !== undefined && index === choice) {
        button.classList.add('is-selected');
      }
    });
  }

  function selectOption(index) {
    if (!session || session.locked) return;
    const question = currentQuestion();
    if (!question || index < 0 || index >= question.options.length) return;

    if (session.mode === 'exam') {
      session.selected = index;
      paintOptions(index, false);
      $('#nextQuestionBtn').disabled = false;
      return;
    }

    const correct = index === question.answer;
    session.selected = index;
    session.locked = true;
    session.answers[session.index] = { qid: question.id, choice: index, correct };
    recordAnswer(question, correct);
    paintOptions(index, true);
    showFeedback(question, correct, index);
    $('#nextQuestionBtn').disabled = false;
  }

  function recordAnswer(question, correct) {
    const stats = state.qstats[question.id] || { seen: 0, correct: 0 };
    stats.seen = Number(stats.seen || 0) + 1;
    stats.correct = Number(stats.correct || 0) + (correct ? 1 : 0);
    state.qstats[question.id] = stats;
    saveState();
  }

  function showFeedback(question, correct, choice) {
    const feedback = $('#qFeedback');
    feedback.hidden = false;
    feedback.className = `feedback ${correct ? 'is-correct' : 'is-wrong'}`;
    $('#feedbackBadge').textContent = correct ? 'صحيح' : 'للمراجعة';
    $('#feedbackTitle').textContent = correct
      ? 'إجابة صحيحة'
      : `الإجابة الصحيحة هي: ${question.options[question.answer]}`;
    $('#feedbackText').textContent = question.exp;
    $('#feedbackSource').textContent = question.source;
  }

  function advance() {
    if (!session) return;
    const question = currentQuestion();
    if (!question) return;

    if (session.mode === 'exam') {
      if (session.selected === null || session.selected === undefined) return;
      if (!session.answers[session.index]) {
        const correct = session.selected === question.answer;
        session.answers[session.index] = { qid: question.id, choice: session.selected, correct };
        recordAnswer(question, correct);
      }
    } else if (!session.answers[session.index]) {
      return;
    }

    if (session.index === session.questions.length - 1) {
      finishSession();
      return;
    }

    session.index += 1;
    session.selected = null;
    session.locked = false;
    renderQuestion();
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  /* ---------------------------------------------------------
     المؤقّت
     --------------------------------------------------------- */

  function elapsedNow() {
    if (!session) return 0;
    return session.elapsedMs + (session.active ? Date.now() - session.tickBase : 0);
  }

  function updateTimer() {
    const timer = $('#playTimer');
    if (timer) timer.textContent = formatDuration(elapsedNow());
  }

  function startTimer() {
    if (!session || session.finished || session.active) return;
    session.active = true;
    session.tickBase = Date.now();
    session.timerId = setInterval(updateTimer, 500);
    updateTimer();
  }

  function stopTimer() {
    if (!session || !session.active) return;
    session.elapsedMs += Date.now() - session.tickBase;
    session.active = false;
    clearInterval(session.timerId);
    session.timerId = null;
    updateTimer();
  }

  /* ---------------------------------------------------------
     نهاية الجلسة
     --------------------------------------------------------- */

  function computeResults() {
    const answers = session.questions.map((question, index) => (
      session.answers[index] || { qid: question.id, choice: null, correct: false }
    ));
    const correct = answers.filter((answer) => answer.correct).length;
    const total = session.questions.length;
    const byCat = {};

    session.questions.forEach((question, index) => {
      if (!byCat[question.cat]) byCat[question.cat] = { correct: 0, total: 0 };
      byCat[question.cat].total += 1;
      if (answers[index].correct) byCat[question.cat].correct += 1;
    });

    return {
      mode: session.mode,
      cat: session.cat,
      label: session.label,
      questions: session.questions,
      answers,
      total,
      correct,
      pct: total ? Math.round((correct / total) * 100) : 0,
      durationMs: session.elapsedMs,
      byCat,
      date: new Date().toISOString()
    };
  }

  function finishSession() {
    if (!session) return;
    stopTimer();

    const results = computeResults();
    results.config = lastConfig ? { ...lastConfig } : null;
    lastResults = results;

    state.history.unshift({
      date: results.date,
      mode: results.mode,
      cat: results.cat,
      total: results.total,
      correct: results.correct,
      pct: results.pct,
      durationMs: results.durationMs
    });
    if (state.history.length > 40) state.history.length = 40;

    state.best = Math.max(Number(state.best) || 0, results.pct);
    state.lastWrong = results.answers.filter((answer) => !answer.correct).map((answer) => answer.qid);
    saveState();

    session = null;

    if (currentView() === 'resultats') renderResults();
    else location.hash = '#resultats';
  }

  /* ---------------------------------------------------------
     النتائج
     --------------------------------------------------------- */

  function resultCopy(pct) {
    if (pct >= 90) {
      return {
        title: 'إتقان الحلبة.',
        text: 'قراءة المواقف وردود الفعل والقرارات: المستوى موجود. حافظ عليه بجلسات منتظمة.'
      };
    }
    if (pct >= 75) {
      return {
        title: 'أداء متين على الحلبة.',
        text: 'الأساسات في مكانها. عُد إلى الأخطاء المشار إليها أدناه لتثبيت التفاصيل الأخيرة.'
      };
    }
    if (pct >= 60) {
      return {
        title: 'الأساسات موجودة.',
        text: 'القاعدة جيدة، لكن بعض المواقف تحتاج إلى تذكير. أعد قراءة الوحدات المعنيّة، ثم أعد الاختبار.'
      };
    }
    if (pct >= 40) {
      return {
        title: 'بحاجة إلى تثبيت.',
        text: 'العلامات المرجعية تتشكّل. قراءة قصيرة للوحدات، ثم اختبار تدريبي، ستصنع الفرق.'
      };
    }
    return {
      title: 'عودة إلى الدرس.',
      text: 'لا تستعجل: اقرأ البطاقات، احفظ الخلاصات، ثم اختبر نفسك من جديد. الصور تساعد كثيرًا.'
    };
  }

  function renderResults() {
    const host = $('#resultsContent');

    if (!lastResults) {
      host.innerHTML = `
        <div class="empty-panel">
          <span class="eyebrow">لا توجد جلسة</span>
          <h2>لا نتيجة بعد</h2>
          <p>ابدأ اختبارًا للحصول على نتيجتك، وتفصيل حسب المحور، ومراجعة كاملة للإجابات.</p>
          <a class="btn btn-primary" href="#quiz" data-nav="quiz">اضبط اختبارًا <span aria-hidden="true">←</span></a>
        </div>`;
      return;
    }

    const results = lastResults;
    const copy = resultCopy(results.pct);
    const wrong = results.total - results.correct;
    const best = bestPercent();
    const catKeys = Object.keys(CATEGORIES).filter((key) => results.byCat[key]);
    const modeLabel = results.mode === 'exam' ? 'امتحان تجريبي' : 'تدريب';
    const contextLabel = results.label || categoryLabel(results.cat);

    const breakdown = catKeys.map((key) => {
      const data = results.byCat[key];
      const category = CATEGORIES[key] || { short: 'محور', color: '#3b82f6' };
      const pct = data.total ? Math.round((data.correct / data.total) * 100) : 0;
      return `
        <div class="breakdown-row">
          <span>${esc(category.short)}</span>
          <div class="breakdown-bar"><i style="width:${pct}%;--accent:${esc(category.color)}"></i></div>
          <strong>\u2067${data.correct} من ${data.total}\u2069</strong>
        </div>`;
    }).join('');

    const review = results.questions.map((question, index) => {
      const answer = results.answers[index];
      const ok = Boolean(answer && answer.correct);
      const given = answer && answer.choice !== null && answer.choice !== undefined
        ? question.options[answer.choice]
        : 'دون إجابة';
      return `
        <details class="review-item"${ok ? '' : ' open'}>
          <summary>
            <span class="review-status ${ok ? 'ok' : 'no'}">${ok ? '✓' : '×'}</span>
            <span>سؤال ${index + 1} · ${esc(question.q)}</span>
          </summary>
          <div class="review-body">
            <div class="review-answer${ok ? '' : ' bad'}">إجابتك: <strong>${esc(given)}</strong></div>
            ${ok ? '' : `<div class="review-answer">الإجابة الصحيحة: <strong>${esc(question.options[question.answer])}</strong></div>`}
            <p>${esc(question.exp)}</p>
            <small>${esc(question.source)} · ${esc(CATEGORIES[question.cat] ? CATEGORIES[question.cat].label : '')}</small>
          </div>
        </details>`;
    }).join('');

    host.innerHTML = `
      <div class="result-hero">
        <div class="result-ring" style="--pct:${results.pct}">
          <div>
            <strong>${results.pct}%</strong>
            <small>نسبة النجاح</small>
          </div>
        </div>
        <div class="result-copy">
          <span class="eyebrow">${modeLabel} · ${esc(contextLabel)}</span>
          <h1>${esc(copy.title)}</h1>
          <p>${esc(copy.text)}</p>
          <div class="result-actions">
            <button class="btn btn-primary" type="button" data-replay>أعد الجلسة <span aria-hidden="true">←</span></button>
            <button class="btn btn-outline" type="button" data-review-errors${wrong ? '' : ' disabled'}>راجع أخطائي</button>
            <a class="btn btn-outline" href="#cours" data-nav="cours">عودة إلى البرنامج</a>
          </div>
        </div>
      </div>

      <div class="result-stats">
        <div class="result-stat"><span>إجابات صحيحة</span><strong>\u2067${results.correct} من ${results.total}\u2069</strong></div>
        <div class="result-stat"><span>أخطاء</span><strong>${wrong}</strong></div>
        <div class="result-stat"><span>الوقت</span><strong>${formatDuration(results.durationMs)}</strong></div>
        <div class="result-stat"><span>أفضل نتيجة</span><strong>${best}%</strong></div>
      </div>

      <div class="result-section">
        <div class="result-section-head">
          <h2>التفصيل حسب المحور</h2>
          <span>${questionsLabel(results.total)}</span>
        </div>
        <div class="breakdown">${breakdown}</div>
      </div>

      <div class="result-section">
        <div class="result-section-head">
          <h2>مراجعة الإجابات</h2>
          <span>تُفتح الأخطاء تلقائيًا</span>
        </div>
        <div class="review-list">${review}</div>
      </div>`;
  }

  /* ---------------------------------------------------------
     التقدّم
     --------------------------------------------------------- */

  function renderProgress() {
    const attempts = QUESTIONS.reduce((total, question) => {
      const stats = state.qstats[question.id];
      return total + (stats ? Number(stats.seen) || 0 : 0);
    }, 0);

    const correct = QUESTIONS.reduce((total, question) => {
      const stats = state.qstats[question.id];
      return total + (stats ? Number(stats.correct) || 0 : 0);
    }, 0);

    const seen = seenQuestions();
    const accuracy = attempts ? Math.round((correct / attempts) * 100) : 0;
    const best = bestPercent();
    const read = readModules();
    const history = state.history;

    const mastery = Object.entries(CATEGORIES).map(([key, category]) => {
      const stats = categoryStats(key);
      return `
        <div class="mastery-row">
          <span>${esc(category.short)}</span>
          <div class="mastery-bar"><i style="width:${stats.pct}%;--accent:${esc(category.color)}"></i></div>
          <strong>${stats.seen ? `${stats.pct}%` : '—'}</strong>
        </div>`;
    }).join('');

    const historyRows = history.slice(0, 8).map((item) => {
      const cat = item.cat === 'all' ? 'كل الأسئلة' : (CATEGORIES[item.cat] ? CATEGORIES[item.cat].short : 'محور');
      const mode = item.mode === 'exam' ? 'امتحان' : 'تدريب';
      return `
        <div class="history-row">
          <span class="history-dot" style="background:${item.mode === 'exam' ? 'var(--red)' : 'var(--blue)'}"></span>
          <div>
            <strong>${mode} · ${esc(cat)}</strong>
            <small>${esc(formatDate(item.date))} · \u2067${item.correct} من ${item.total}\u2069 · ${formatDuration(item.durationMs)}</small>
          </div>
          <span class="history-score ${item.pct >= 70 ? 'good' : 'bad'}">${item.pct}%</span>
        </div>`;
    }).join('');

    $('#progressContent').innerHTML = `
      <div class="progress-stats">
        <div class="progress-card"><span>وحدات مقروءة</span><strong>\u2066${read}/${MODULES.length}\u2069</strong><small>البرنامج</small></div>
        <div class="progress-card"><span>أسئلة شوهدت</span><strong>\u2066${seen}/${QUESTIONS.length}\u2069</strong><small>التغطية</small></div>
        <div class="progress-card"><span>الدقة</span><strong>${accuracy}%</strong><small>${answersLabel(attempts)}</small></div>
        <div class="progress-card"><span>أفضل نتيجة</span><strong>${best}%</strong><small>${sessionsLabel(history.length)}</small></div>
      </div>

      <div class="progress-columns">
        <div class="progress-panel">
          <h2>الإتقان حسب المحور</h2>
          <div class="mastery-list">${mastery}</div>
          <p class="panel-note">محسوب من إجاباتك. البرنامج: \u2067${read} من ${MODULES.length} وحدات مقروءة\u2069 · \u2067${seen} من ${QUESTIONS.length} سؤالًا شوهد\u2069.</p>
        </div>
        <div class="progress-panel">
          <h2>آخر الجلسات</h2>
          ${historyRows || `
            <div class="empty-state">
              <strong>لا توجد جلسات بعد</strong>
              ستظهر نتائجك هنا بعد أوّل اختبار.
            </div>`}
          ${history.length ? `<p class="panel-note">${sessionsLabel(history.length)} محفوظة على هذا الجهاز.</p>` : ''}
        </div>
      </div>`;
  }

  /* ---------------------------------------------------------
     التنبيهات، العارض، النوافذ
     --------------------------------------------------------- */

  function toast(message) {
    const element = $('#toast');
    if (!element) return;
    element.textContent = message;
    element.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => element.classList.remove('is-visible'), 2400);
  }

  function openLightbox(src, caption) {
    if (!src) return;
    stopTimer();
    $('#lightboxImg').src = src;
    $('#lightboxImg').alt = caption || '';
    $('#lightboxCaption').textContent = caption || '';
    $('#lightbox').hidden = false;
    document.body.classList.add('no-scroll');
    $('#lightboxClose').focus();
  }

  function closeLightbox() {
    $('#lightbox').hidden = true;
    $('#lightboxImg').src = '';
    document.body.classList.remove('no-scroll');
    if (currentView() === 'quiz' && session && !session.finished && $('#quitModal').hidden) startTimer();
  }

  function openQuit() {
    if (!session) return;
    stopTimer();
    $('#quitModal').hidden = false;
    document.body.classList.add('no-scroll');
    $('#cancelQuitBtn').focus();
  }

  function closeQuit() {
    $('#quitModal').hidden = true;
    document.body.classList.remove('no-scroll');
    if (currentView() === 'quiz' && session && !session.finished && $('#lightbox').hidden) startTimer();
  }

  function confirmQuit() {
    $('#quitModal').hidden = true;
    document.body.classList.remove('no-scroll');
    if (session) stopTimer();
    session = null;
    renderQuiz();
    toast('تم الخروج من الجلسة.');
  }

  function resetProgress() {
    const confirmed = window.confirm('هل تريد إعادة تصفير كل سجلّك ونتائجك والوحدات المقروءة؟ هذا الإجراء نهائي.');
    if (!confirmed) return;

    if (session) stopTimer();
    session = null;
    lastResults = null;
    lastConfig = null;
    resetState();
    renderProgress();
    toast('تمت إعادة تصفير التقدّم.');
  }

  /* ---------------------------------------------------------
     القائمة والتنقّل
     --------------------------------------------------------- */

  function closeMenu() {
    $('#mainNav').classList.remove('is-open');
    $('#menuBtn').setAttribute('aria-expanded', 'false');
    $('#menuBtn').setAttribute('aria-label', 'فتح القائمة');
  }

  function toggleMenu() {
    const open = $('#mainNav').classList.toggle('is-open');
    $('#menuBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
    $('#menuBtn').setAttribute('aria-label', open ? 'إغلاق القائمة' : 'فتح القائمة');
  }

  const VIEWS = ['accueil', 'cours', 'lecon', 'quiz', 'resultats', 'progression', 'sessions'];
  const TITLES = {
    accueil: 'الرئيسية',
    cours: 'البرنامج',
    lecon: 'الدرس',
    quiz: 'الاختبار',
    resultats: 'النتائج',
    progression: 'التقدّم',
    sessions: 'الجلسات'
  };

  function route() {
    const raw = (location.hash || '#accueil').replace(/^#/, '') || 'accueil';
    const parts = raw.split('/');
    const view = parts[0];
    const param = parts[1];

    if (!VIEWS.includes(view)) {
      location.replace('#accueil');
      return;
    }

    if (view === 'lecon' && !MODULES.some((module) => module.id === param)) {
      location.replace('#cours');
      return;
    }

    if (session && session.active) stopTimer();
    closeMenu();

    $$('.view').forEach((element) => { element.hidden = true; });
    const target = $(`#view-${view}`);
    if (target) target.hidden = false;

    const navMap = { lecon: 'cours', resultats: 'quiz' };
    const navKey = navMap[view] || view;
    $$('.main-nav a').forEach((link) => {
      link.classList.toggle('is-active', link.dataset.nav === navKey);
    });

    document.title = `${TITLES[view] || 'أكاديمية الحلبة'} — أكاديمية الحلبة`;

    if (view === 'lecon') {
      const module = MODULES.find((item) => item.id === param);
      if (module) document.title = `${module.title} — أكاديمية الحلبة`;
    }

    if (view === 'accueil') renderHome();
    else if (view === 'cours') renderCourse();
    else if (view === 'lecon') renderLesson(param);
    else if (view === 'quiz') renderQuiz();
    else if (view === 'resultats') renderResults();
    else if (view === 'progression') renderProgress();
    else if (view === 'sessions' && window.RingSessions) window.RingSessions.render();

    window.scrollTo({ top: 0, behavior: 'auto' });

    if (view === 'quiz' && session && !session.finished && $('#quitModal').hidden && $('#lightbox').hidden) {
      startTimer();
    }
  }

  /* ---------------------------------------------------------
     الأحداث
     --------------------------------------------------------- */

  function handleGlobalClick(event) {
    if (event.target.closest('[data-nav]')) closeMenu();

    const lightboxTrigger = event.target.closest('[data-lightbox]');
    if (lightboxTrigger) {
      event.preventDefault();
      openLightbox(lightboxTrigger.dataset.lightbox, lightboxTrigger.dataset.caption || '');
      return;
    }

    const readButton = event.target.closest('[data-toggle-read]');
    if (readButton) {
      const id = readButton.dataset.toggleRead;
      const module = MODULES.find((item) => item.id === id);
      if (!module) return;
      const wasRead = Boolean(state.modulesRead[id]);
      if (wasRead) delete state.modulesRead[id];
      else state.modulesRead[id] = true;
      saveState();
      updateCourseMeter();
      if (currentView() === 'lecon') renderLesson(id);
      toast(wasRead ? 'أُزيل تعليم الوحدة كمقروءة.' : 'عُلّمت الوحدة كمقروءة.');
      return;
    }

    const quizTrigger = event.target.closest('[data-quiz-cat]');
    if (quizTrigger) {
      event.preventDefault();
      const cat = quizTrigger.dataset.quizCat;
      if (CATEGORIES[cat]) selectedCat = cat;

      if (currentView() === 'quiz') {
        if (!session) {
          $('#quizSetup').hidden = false;
          $('#quizPlay').hidden = true;
          renderCategoryGrid();
        } else {
          toast('أنهِ الجلسة الجارية أو اخرج منها أولًا.');
        }
      } else {
        if (session && !session.finished) {
          toast('تمّت استعادة الجلسة الجارية. أنهِها أو اخرج منها قبل بدء جلسة أخرى.');
        }
        location.hash = '#quiz';
      }
    }
  }

  function bindEvents() {
    $('#menuBtn').addEventListener('click', toggleMenu);

    document.addEventListener('click', handleGlobalClick);
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        if (!$('#quitModal').hidden) { closeQuit(); return; }
        if (!$('#lightbox').hidden) { closeLightbox(); return; }
        closeMenu();
        return;
      }

      if (!$('#quitModal').hidden || !$('#lightbox').hidden) return;
      if (event.altKey || event.ctrlKey || event.metaKey) return;
      if (currentView() !== 'quiz' || !session) return;

      const target = event.target instanceof Element ? event.target : document.body;
      if (target.closest('input, textarea, select')) return;

      if (/^[1-4]$/.test(event.key)) {
        const button = $$('#qOptions .option')[Number(event.key) - 1];
        if (button && !button.disabled) {
          event.preventDefault();
          button.click();
        }
        return;
      }

      if (event.key === 'Enter') {
        if (target.closest('.option')) return;
        const next = $('#nextQuestionBtn');
        if (next && !next.disabled) {
          event.preventDefault();
          next.click();
        }
      }
    });

    $('#modeGrid').addEventListener('click', (event) => {
      const card = event.target.closest('.mode-card');
      if (!card) return;
      selectedMode = card.dataset.mode === 'exam' ? 'exam' : 'training';
      syncSetupUI();
    });

    $('#categoryGrid').addEventListener('click', (event) => {
      const card = event.target.closest('.cat-card');
      if (!card) return;
      const cat = card.dataset.cat;
      if (cat === 'all' || CATEGORIES[cat]) selectedCat = cat;
      syncSetupUI();
    });

    $('#quizSetup').addEventListener('click', (event) => {
      const countButton = event.target.closest('.count-btn');
      if (!countButton) return;
      selectedCount = countButton.dataset.count === 'all' ? 'all' : Number(countButton.dataset.count);
      syncSetupUI();
    });

    $('#shuffleToggle').addEventListener('change', syncSetupUI);

    $('#startQuizBtn').addEventListener('click', () => {
      launchFromConfig({
        mode: selectedMode,
        cat: selectedCat,
        count: selectedCount,
        shuffle: $('#shuffleToggle').checked
      });
    });

    $('#qOptions').addEventListener('click', (event) => {
      const option = event.target.closest('.option');
      if (!option) return;
      selectOption(Number(option.dataset.index));
    });

    $('#nextQuestionBtn').addEventListener('click', advance);
    $('#quitQuizBtn').addEventListener('click', openQuit);
    $('#zoomBtn').addEventListener('click', () => {
      const question = currentQuestion();
      if (!question || !question.img) return;
      openLightbox(question.img, question.alt || question.q);
    });
    $('#cancelQuitBtn').addEventListener('click', closeQuit);
    $('#confirmQuitBtn').addEventListener('click', confirmQuit);

    $('#feedbackCourseBtn').addEventListener('click', () => {
      if (!session) return;
      const question = currentQuestion();
      if (question) location.hash = `#lecon/${question.cat}`;
    });

    $('#lightboxClose').addEventListener('click', closeLightbox);
    $('#lightbox').addEventListener('click', (event) => {
      if (event.target === $('#lightbox')) closeLightbox();
    });

    $('#resetProgressBtn').addEventListener('click', resetProgress);

    $('#resultsContent').addEventListener('click', (event) => {
      const replay = event.target.closest('[data-replay]');
      if (replay) {
        if (lastResults && lastResults.config) launchFromConfig(lastResults.config);
        else location.hash = '#quiz';
        return;
      }

      const reviewErrors = event.target.closest('[data-review-errors]');
      if (reviewErrors) {
        const ids = new Set(state.lastWrong);
        const questions = QUESTIONS.filter((question) => ids.has(question.id));
        if (!questions.length) {
          toast('لا توجد أخطاء للمراجعة.');
          return;
        }
        startSession({
          mode: 'training',
          cat: 'all',
          count: questions.length,
          shuffle: false,
          label: 'أخطائي',
          questions
        });
      }
    });

    window.addEventListener('hashchange', route);

    document.addEventListener('ringcatalogchange', () => {
      if (selectedCat !== 'all' && !CATEGORIES[selectedCat]) selectedCat = 'all';
      refreshCounts();
      if (session && session.active && !session.finished) return;
      const view = currentView();
      if (view === 'accueil') renderHome();
      else if (view === 'cours') renderCourse();
      else if (view === 'quiz') renderQuiz();
      else if (view === 'progression') renderProgress();
      else if (view === 'resultats') renderResults();
      else if (view === 'sessions' && window.RingSessions) window.RingSessions.render();
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        stopTimer();
      } else if (currentView() === 'quiz' && session && !session.finished && $('#quitModal').hidden && $('#lightbox').hidden) {
        startTimer();
      }
    });
  }

  /* ---------------------------------------------------------
     الانطلاق
     --------------------------------------------------------- */

  function init() {
    $('#year').textContent = new Date().getFullYear();
    refreshCounts();

    renderCategoryGrid();
    bindEvents();
    route();
  }

  init();

})();
