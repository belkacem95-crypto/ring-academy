/* =========================================================
   Ring Academy — mises à jour (application + contenu)
   Panneau arabe RTL. Ne fait rien hors de l'APK Android :
   le pont window.Updater est injecté par MainActivity.
   ========================================================= */
(function () {
  'use strict';

  var bridge = window.Updater;
  if (!bridge || typeof bridge.state !== 'function') return;

  var IP_KEY = 'ringAcademy.exam.ip';
  var POLL_MS = 1200;

  var PHASE_LABEL = {
    idle: 'محدَّث',
    checking: 'جارٍ الفحص…',
    available: 'تحديث متوفّر',
    downloading: 'جارٍ التحميل…',
    ready: 'جاهز للتثبيت',
    installing: 'جارٍ التثبيت…',
    'content-ready': 'محتوى جاهز',
    applying: 'جارٍ التطبيق…',
    error: 'تعذّر'
  };

  var PHASE_TONE = {
    idle: 'ok',
    checking: 'busy',
    available: 'warn',
    downloading: 'busy',
    ready: 'warn',
    installing: 'busy',
    'content-ready': 'warn',
    applying: 'busy',
    error: 'error'
  };

  var state = null;
  var panel = null;
  var card = null;
  var banner = null;
  var pollTimer = null;
  var lastPhase = '';

  var TEMPLATE = ''
    + '<details class="update-card" id="updateCard">'
    + '  <summary class="update-summary">'
    + '    <span class="update-summary-main">'
    + '      <span class="kicker">تحديثات</span>'
    + '      <strong>التطبيق والمحتوى</strong>'
    + '      <small id="updateVersions">—</small>'
    + '    </span>'
    + '    <span class="update-badge" id="updateBadge">—</span>'
    + '  </summary>'
    + '  <div class="update-body">'
    + '    <p class="update-message" id="updateMessage"></p>'
    + '    <div class="update-bar" id="updateBar" hidden><span id="updateBarFill"></span></div>'
    + '    <p class="update-meta" id="updateMeta" hidden></p>'
    + '    <div class="update-actions">'
    + '      <button class="btn btn-primary" type="button" data-update-act="check">فحص التحديثات</button>'
    + '      <button class="btn btn-primary" type="button" data-update-act="download-app" hidden>تحميل التطبيق</button>'
    + '      <button class="btn btn-primary" type="button" data-update-act="install" hidden>تثبيت التحديث</button>'
    + '      <button class="btn btn-outline" type="button" data-update-act="download-content" hidden>تحميل المحتوى</button>'
    + '      <button class="btn btn-outline" type="button" data-update-act="apply" hidden>تطبيق المحتوى</button>'
    + '      <button class="btn btn-outline" type="button" data-update-act="settings" hidden>السماح بالتثبيت</button>'
    + '    </div>'
    + '    <p class="update-note" id="updateInstallNote" hidden></p>'
    + '    <div class="update-advanced">'
    + '      <span class="field-label">مصدر Wi-Fi للمدرب</span>'
    + '      <div class="update-lan-row">'
    + '        <input id="updateLan" type="text" dir="ltr" inputmode="url" autocomplete="off" spellcheck="false" placeholder="http://192.168.43.1:8765/update/">'
    + '        <button class="btn btn-outline" type="button" data-update-act="save-lan">حفظ وفحص</button>'
    + '      </div>'
    + '      <p class="update-hint">عنوان هاتف المدرب على شبكته. يظهر في صفحة الجلسات عند المدرب.</p>'
    + '      <button class="update-hub" id="updateHub" type="button" data-update-act="copy-hub" hidden></button>'
    + '      <div class="update-links">'
    + '        <button class="text-link" type="button" data-update-act="import" hidden>استيراد حزمة تحديث</button>'
    + '        <button class="text-link" type="button" data-update-act="reset" hidden>استعادة المحتوى المدمج</button>'
    + '        <button class="text-link" type="button" data-update-act="reload">إعادة تحميل الواجهة</button>'
    + '      </div>'
    + '    </div>'
    + '  </div>'
    + '</details>';

  var BANNER = ''
    + '<button class="update-banner" id="updateBanner" type="button" hidden>'
    + '  <span class="update-banner-dot" aria-hidden="true"></span>'
    + '  <span class="update-banner-text" id="updateBannerText">يوجد تحديث متوفّر</span>'
    + '  <span class="update-banner-go">عرض</span>'
    + '</button>';

  function $(id) {
    return document.getElementById(id);
  }

  function read() {
    try {
      var raw = bridge.state();
      return raw ? JSON.parse(raw) : null;
    } catch (error) {
      return null;
    }
  }

  function readIp() {
    try {
      return (localStorage.getItem(IP_KEY) || '').trim();
    } catch (error) {
      return '';
    }
  }

  function formatBytes(value) {
    var bytes = Number(value) || 0;
    if (!bytes) return '';
    if (bytes < 1024 * 1024) return Math.max(1, Math.round(bytes / 1024)) + ' ك.ب';
    return (Math.round((bytes / (1024 * 1024)) * 10) / 10) + ' م.ب';
  }

  function setText(id, text) {
    var node = $(id);
    if (node) node.textContent = text;
  }

  function show(id, visible) {
    var node = $(id);
    if (node) node.hidden = !visible;
  }

  function setAction(name, visible, disabled) {
    var nodes = card.querySelectorAll('[data-update-act="' + name + '"]');
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].hidden = !visible;
      nodes[i].disabled = !!disabled;
    }
  }

  function update() {
    var current = read();
    if (!current || !current.ok) return;
    state = current;

    var app = current.app || null;
    var content = current.content || null;
    var busy = current.phase === 'checking'
      || current.phase === 'downloading'
      || current.phase === 'installing'
      || current.phase === 'applying';

    var badge = $('updateBadge');
    if (badge) {
      badge.textContent = PHASE_LABEL[current.phase] || current.phase || '—';
      badge.setAttribute('data-tone', PHASE_TONE[current.phase] || 'ok');
    }

    var versions = 'الإصدار ' + (current.versionName || '—')
      + ' · المحتوى ' + (current.contentVersion || 0);
    if (app && app.versionName) versions += ' → ' + app.versionName;
    else if (content && content.version) versions += ' → ' + content.version;
    setText('updateVersions', versions);

    setText('updateMessage', current.message || '');

    var bar = $('updateBar');
    var fill = $('updateBarFill');
    var showBar = busy || (current.progress > 0 && current.progress < 100);
    if (bar) bar.hidden = !showBar;
    if (fill) fill.style.width = Math.max(0, Math.min(100, current.progress || 0)) + '%';

    var meta = [];
    if (app) {
      var appLine = 'التطبيق: ' + (current.versionName || '?') + ' → ' + (app.versionName || '?');
      var appSize = formatBytes(app.size);
      if (appSize) appLine += ' · ' + appSize;
      meta.push(appLine);
    }
    if (content) {
      var contentLine = 'المحتوى: ' + (current.contentVersion || 0) + ' → ' + (content.version || '?');
      var contentSize = formatBytes(content.size);
      if (contentSize) contentLine += ' · ' + contentSize;
      meta.push(contentLine);
    }
    var metaNode = $('updateMeta');
    if (metaNode) {
      metaNode.textContent = meta.join(' — ');
      metaNode.hidden = meta.length === 0;
    }

    setAction('check', true, busy);
    setAction('download-app', !!app && !current.appReady, busy);
    setAction('install', !!app && !!current.appReady, busy);
    setAction('download-content', !!content && !current.contentPending, busy);
    setAction('apply', !!current.contentPending, busy);
    setAction('settings', !current.canInstall, busy);
    setAction('reset', (current.appliedContent || 0) > (current.embeddedContent || 0), busy);
    setAction('import', current.appId === 'coach', busy);

    var note = $('updateInstallNote');
    if (note) {
      var text = '';
      if (current.installStatus) text = current.installStatus;
      else if (!current.canInstall) text = 'اسمح للتطبيق بتثبيت التحديثات من الإعدادات.';
      note.textContent = text;
      note.hidden = !text;
    }

    var lan = $('updateLan');
    if (lan && document.activeElement !== lan && current.lanBase) {
      lan.value = current.lanBase;
    }

    var hub = $('updateHub');
    if (hub) {
      var address = coachHubAddress(current);
      hub.hidden = !address;
      if (address) {
        hub.textContent = 'عنوان المشاركة: ' + address;
        hub.setAttribute('data-address', address);
        hub.title = 'اضغط للنسخ';
      }
    }

    var alerting = current.phase === 'available'
      || current.phase === 'ready'
      || current.phase === 'content-ready';
    if (banner) {
      banner.hidden = !alerting;
      if (alerting) {
        setText('updateBannerText', current.phase === 'content-ready'
          ? 'المحتوى الجديد جاهز للتطبيق'
          : (current.phase === 'ready' ? 'التحديث جاهز للتثبيت' : 'يوجد تحديث متوفّر'));
      }
    }

    if (alerting && lastPhase !== current.phase && card && !card.open) {
      card.open = true;
    }
    lastPhase = current.phase;
  }

  function coachHubAddress(current) {
    if (!current || current.appId !== 'coach') return '';
    if (!window.Coach || typeof window.Coach.info !== 'function') return '';
    try {
      var info = JSON.parse(window.Coach.info());
      var ips = info && info.ips ? info.ips : [];
      if (!ips.length) return '';
      return 'http://' + ips[0] + ':8765/update/';
    } catch (error) {
      return '';
    }
  }

  function lanValue() {
    var input = $('updateLan');
    var value = input && input.value ? input.value.trim() : '';
    if (!value && state) value = state.lanBase || '';
    return value;
  }

  function copyText(text) {
    if (!text) return;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
        return;
      }
    } catch (error) {
      /* continue */
    }
    try {
      var area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      document.body.removeChild(area);
    } catch (error) {
      /* rien à faire */
    }
  }

  function act(name) {
    switch (name) {
      case 'check':
        bridge.check(lanValue());
        break;
      case 'save-lan':
        bridge.setLanBase(lanValue());
        bridge.check(lanValue());
        break;
      case 'download-app':
        bridge.downloadApp();
        break;
      case 'install':
        bridge.installApp();
        break;
      case 'download-content':
        bridge.downloadContent();
        break;
      case 'apply':
        bridge.applyContent();
        break;
      case 'settings':
        bridge.openInstallSettings();
        break;
      case 'import':
        bridge.importPackage();
        break;
      case 'reset':
        if (window.confirm('هل تريد حذف المحتوى المُحدَّث والعودة إلى نسخة التطبيق المدمجة؟')) {
          bridge.resetContent();
        }
        break;
      case 'reload':
        bridge.reload();
        break;
      case 'copy-hub': {
        var hub = $('updateHub');
        if (hub) copyText(hub.getAttribute('data-address') || '');
        break;
      }
      default:
        break;
    }
    setTimeout(update, 150);
  }

  function openPanel() {
    if (!panel) return;
    if (card) card.open = true;
    var progression = document.getElementById('view-progression');
    if (progression && progression.hidden) {
      window.location.hash = '#progression';
    }
    setTimeout(function () {
      if (panel.scrollIntoView) {
        panel.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 220);
  }

  function mount() {
    panel = document.getElementById('updatePanel');
    if (!panel) return false;

    panel.innerHTML = TEMPLATE;
    card = $('updateCard');

    var host = document.createElement('div');
    host.innerHTML = BANNER;
    banner = host.firstChild;
    document.body.appendChild(banner);

    panel.addEventListener('click', function (event) {
      var button = event.target.closest ? event.target.closest('[data-update-act]') : null;
      if (!button || !panel.contains(button)) return;
      act(button.getAttribute('data-update-act'));
    });

    banner.addEventListener('click', openPanel);
    return true;
  }

  function boot() {
    if (!mount()) return;

    // Application « Examen » : réutilise l'adresse du coach déjà découverte,
    // mais ne remplace jamais une adresse choisie par l'utilisateur.
    var ip = readIp();
    var saved = read();
    if (ip && saved && saved.ok && !saved.lanBase) {
      try {
        bridge.setLanBase('http://' + ip + ':8765/update/');
      } catch (error) {
        /* rien à faire */
      }
    }

    update();
    pollTimer = setInterval(update, POLL_MS);
    window.addEventListener('ringupdate', update);
    window.addEventListener('beforeunload', function () {
      if (pollTimer) clearInterval(pollTimer);
    });

    var initial = read();
    if (initial && initial.ok && (initial.internet || initial.lanBase)) {
      setTimeout(function () {
        bridge.check(initial.lanBase || '');
      }, 2500);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
