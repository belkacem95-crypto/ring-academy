/* =========================================================
   أكاديمية الحلبة — تطبيق الامتحان (المشارك)
   يتصل بهاتف المدرب على الشبكة المحلية، دون أيّ إنترنت.
   ========================================================= */

(() => {
  'use strict';

  const PORT = 8765;
  const STORE_KEY = 'ringAcademy.exam.v1';
  const IP_KEY = 'ringAcademy.exam.ip';
  const NAME_KEY = 'ringAcademy.exam.name';
  /* بوّابات شبكات نقطة الاتصال الشائعة (كل الشركات المصنّعة تقريبًا).
     يُجرَّب العنوان المحفوظ واليدوي أولًا، ثم القائمة القصيرة، ثم المسح الكامل. */
  const QUICK = [
    '192.168.43.1', '192.168.49.1', '192.168.137.1', '172.20.10.1',
    '192.168.1.1', '192.168.0.1', '192.168.232.1', '10.0.2.2'
  ];

  const CANDIDATES = (() => {
    const list = QUICK.slice();
    const add = (ip) => {
      if (list.indexOf(ip) < 0) list.push(ip);
    };
    for (let i = 0; i <= 49; i += 1) add(`192.168.${i}.1`);
    [100, 101, 102, 103, 104, 105, 168, 233, 234, 235, 236, 238, 239, 240].forEach((i) => add(`192.168.${i}.1`));
    ['10.0.0.1', '10.0.1.1', '10.0.2.1', '10.0.3.1', '10.42.0.1', '10.143.0.1', '172.20.10.2'].forEach(add);
    return list;
  })();

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));

  const isolate = (value) => `\u2066${value}\u2069`;

  let session = null;
  let pending = {};
  let flushPromise = null;
  let pollTimer = null;
  let tickTimer = null;
  let retryTimer = null;
  let submitting = false;
  let discoveredIp = null;
  let joinBusy = false;
  let watchTimer = null;

  /* ------------------------------------------------------------------ */
  /* أدوات                                                              */
  /* ------------------------------------------------------------------ */

  function show(screen) {
    ['screenJoin', 'screenLobby', 'screenQuiz', 'screenDone'].forEach((id) => {
      const element = document.getElementById(id);
      if (element) element.hidden = id !== screen;
    });
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  function toast(message) {
    const element = $('#toast');
    if (!element) return;
    element.textContent = message;
    element.classList.add('is-visible');
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => element.classList.remove('is-visible'), 2800);
  }

  function formatClock(ms) {
    const total = Math.max(0, Math.round((Number(ms) || 0) / 1000));
    const minutes = Math.floor(total / 60);
    return isolate(`${String(minutes).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`);
  }

  function formatTime(ms) {
    const total = Math.max(0, Math.round((Number(ms) || 0) / 1000));
    const minutes = Math.floor(total / 60);
    return minutes === 0
      ? isolate(`${total} ثانية`)
      : isolate(`${minutes} د ${String(total % 60).padStart(2, '0')} ث`);
  }

  function durationLabel(seconds) {
    const minutes = Math.round((Number(seconds) || 0) / 60);
    return minutes === 1 ? 'دقيقة' : minutes === 2 ? 'دقيقتان' : `${minutes} دقائق`;
  }

  function normalizeIp(raw) {
    let value = String(raw || '').trim();
    if (!value) return null;
    value = value.replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
    if (value.indexOf(':') >= 0) value = value.split(':')[0];
    return /^\d{1,3}(\.\d{1,3}){3}$/.test(value) ? value : null;
  }

  function firstSuccess(promises) {
    return new Promise((resolve, reject) => {
      let pendingCount = promises.length;
      if (!pendingCount) {
        reject(new Error('none'));
        return;
      }
      promises.forEach((promise) => {
        Promise.resolve(promise).then(resolve, () => {
          pendingCount -= 1;
          if (pendingCount === 0) reject(new Error('none'));
        });
      });
    });
  }

  /* ------------------------------------------------------------------ */
  /* الشبكة                                                             */
  /* ------------------------------------------------------------------ */

  function request(ip, path, options, timeoutMs) {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => {
      if (controller) controller.abort();
    }, timeoutMs || 4500);

    const settings = { cache: 'no-store', method: (options && options.method) || 'GET' };
    if (options && options.body) {
      settings.body = options.body;
      settings.headers = { 'Content-Type': 'text/plain;charset=UTF-8' };
    }
    if (controller) settings.signal = controller.signal;

    return fetch(`http://${ip}:${PORT}${path}`, settings).then((response) => {
      clearTimeout(timer);
      return response.text().then((text) => {
        let data = null;
        try {
          data = JSON.parse(text);
        } catch (error) {
          data = null;
        }
        if (!response.ok || !data) throw new Error('http');
        return data;
      });
    }).catch((error) => {
      clearTimeout(timer);
      throw error;
    });
  }

  function post(ip, path, payload) {
    return request(ip, path, { method: 'POST', body: JSON.stringify(payload) }, 6000);
  }

  function ping(ip) {
    return request(ip, '/ping', null, 2400).then((data) => {
      if (data && data.ok && data.app === 'ring-academy') return ip;
      throw new Error('ping');
    });
  }

  // يجرّب قائمة عناوين بالتوازي ويعيد أوّل عنوان يستجيب.
  function sweep(list, timeoutMs) {
    if (!list.length) return Promise.reject(new Error('none'));
    return firstSuccess(list.map((ip) => request(ip, '/ping', null, timeoutMs).then((data) => {
      if (data && data.ok && data.app === 'ring-academy') return ip;
      throw new Error('ping');
    })));
  }

  function uniqueList(values) {
    const out = [];
    values.forEach((value) => {
      const clean = normalizeIp(value);
      if (clean && out.indexOf(clean) < 0) out.push(clean);
    });
    return out;
  }

  let discovery = null;

  function discover(options) {
    const opts = options || {};
    if (discovery && !opts.force) return discovery;

    const manual = normalizeIp($('#ipInput').value);
    const stored = localStorage.getItem(IP_KEY);
    const head = uniqueList([manual, stored, discoveredIp]);
    const rest = CANDIDATES.filter((ip) => head.indexOf(ip) < 0);

    setNetStatus('searching', 'جارٍ البحث عن هاتف المدرب…');

    discovery = sweep(head.concat(QUICK.filter((ip) => head.indexOf(ip) < 0)), 1800)
      .catch(() => sweep(head.concat(rest), 2400))
      .then((ip) => {
        discoveredIp = ip;
        setNetStatus('ok', `تم العثور على المدرب — ${isolate(ip)}`);
        const input = $('#ipInput');
        if (input) input.placeholder = ip;
        return ip;
      })
      .catch(() => {
        discoveredIp = null;
        setNetStatus('error', 'لم يُعثر على المدرب. اكتب عنوانه يدويًا أو أعد المحاولة.');
        return null;
      });

    const current = discovery;
    current.then(() => {
      if (discovery === current) discovery = null;
    }, () => {
      if (discovery === current) discovery = null;
    });
    return current;
  }


  function setNetStatus(kind, text) {
    const box = $('#netStatus');
    if (!box) return;
    box.className = `net-status${kind === 'ok' ? ' is-ok' : kind === 'error' ? ' is-error' : ''}`;
    $('#netStatusText').textContent = text;
  }

  function netOk() {
    const banner = $('#netBanner');
    if (banner) banner.hidden = true;
  }

  function netFail() {
    const banner = $('#netBanner');
    if (banner) banner.hidden = false;
  }

  /* ------------------------------------------------------------------ */
  /* الجلسة                                                             */
  /* ------------------------------------------------------------------ */

  function loadStored() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || !parsed.token || !parsed.ip) return null;
      return parsed;
    } catch (error) {
      return null;
    }
  }

  function saveStored() {
    if (!session) return;
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({
        ip: session.ip,
        token: session.token,
        name: session.name,
        code: session.code,
        title: session.title,
        total: session.total,
        durationSec: session.durationSec
      }));
    } catch (error) {
      /* stockage indisponible : la session reste en mémoire */
    }
  }

  function clearStored() {
    try {
      localStorage.removeItem(STORE_KEY);
    } catch (error) {
      /* rien à faire */
    }
  }

  function resume() {
    const stored = loadStored();
    if (!stored) {
      discover();
      return;
    }

    session = {
      ip: stored.ip,
      token: stored.token,
      name: stored.name,
      code: stored.code,
      title: stored.title,
      total: stored.total,
      durationSec: stored.durationSec,
      questions: [],
      answers: [],
      index: 0,
      deadline: 0,
      ended: false
    };

    request(session.ip, `/state?token=${encodeURIComponent(session.token)}`, null, 3500).then((state) => {
      if (!state.ok) {
        clearStored();
        session = null;
        discover();
        return;
      }
      setNetStatus('ok', `متّصل بالمدرب — ${isolate(session.ip)}`);
      applyState(state, true);
    }).catch(() => {
      clearStored();
      session = null;
      setNetStatus('error', 'تعذّر استئناف الجلسة. أعد الانضمام بالرمز.');
      discover();
    });
  }

  function applyState(state, resuming) {
    if (!session) return;
    netOk();
    session.title = state.title || session.title;
    session.total = state.total || session.total;
    session.durationSec = state.durationSec || session.durationSec;
    session.name = state.name || session.name;

    if (state.submitted) {
      showDone(state.score, state.total, state.timeMs);
      return;
    }

    if (state.phase === 'lobby') {
      showLobby(state);
      startPolling();
      return;
    }

    if (state.phase === 'running' || state.phase === 'ended') {
      if (!session.questions.length) loadQuestions(state);
      else {
        if (state.phase === 'running') session.deadline = Date.now() + (state.remainingMs || 0);
        if (state.phase === 'ended') {
          session.ended = true;
          submitNow(true);
        }
        updateTimer();
      }
      return;
    }

    if (state.phase === 'stopped' || state.phase === 'idle') {
      leaveSession('أوقفت الجلسة من طرف المدرب.');
    }
  }

  function join() {
    if (joinBusy) return;
    const name = $('#nameInput').value.replace(/\s+/g, ' ').trim();
    const code = $('#codeInput').value.trim();
    const manual = normalizeIp($('#ipInput').value);

    $('#joinError').hidden = true;
    if (name.length < 2) {
      joinError('اكتب اسمًا صحيحًا (حرفان على الأقل).');
      return;
    }
    if (!/^\d{4}$/.test(code)) {
      joinError('رمز الجلسة يتكوّن من أربعة أرقام.');
      return;
    }
    if ($('#ipInput').value.trim() && !manual) {
      joinError('عنوان الشبكة غير صالح. مثال: 192.168.43.1');
      return;
    }

    joinBusy = true;
    $('#joinBtn').disabled = true;
    $('#joinBtn').textContent = 'جارٍ الانضمام…';

    const sendJoin = (target) => post(target, '/join', { name, code })
      .then(
        (data) => ({ target, data }),
        () => { throw new Error('net'); }
      );

    // لا نثق بعنوان محفوظ: نتحقّق منه، ونعيد الاكتشاف عند أي فشل شبكي.
    const reach = manual
      ? Promise.resolve(manual)
      : discover({ force: true }).then((found) => {
        if (!found) throw new Error('offline');
        return found;
      });

    reach.then((target) => sendJoin(target).catch((error) => {
      if (!error || error.message !== 'net') throw error;
      return discover({ force: true }).then((found) => {
        if (!found) throw new Error('offline');
        return sendJoin(found);
      });
    })).then((result) => {
      const data = result.data;
      if (!data.ok) {
        throw new Error(data.error || 'join');
      }
      session = {
        ip: result.target,
        token: data.token,
        name: data.name,
        code,
        title: data.title,
        total: data.total,
        durationSec: data.durationSec,
        questions: [],
        answers: [],
        index: 0,
        deadline: 0,
        ended: false
      };
      try {
        localStorage.setItem(IP_KEY, result.target);
        localStorage.setItem(NAME_KEY, name);
      } catch (error) {
        /* stockage indisponible */
      }
      saveStored();
      discoveredIp = result.target;
      setNetStatus('ok', `متّصل بالمدرب — ${isolate(result.target)}`);
      showLobby(data);
      startPolling();
    }).catch((error) => {
      joinError(joinErrorText(error.message));
    }).then(() => {
      joinBusy = false;
      $('#joinBtn').disabled = false;
      $('#joinBtn').innerHTML = 'انضم إلى الجلسة <span aria-hidden="true">←</span>';
    });
  }

  function joinErrorText(code) {
    if (code === 'code') return 'رمز الجلسة غير صحيح. تحقّق من الرقم الذي يعرضه المدرب.';
    if (code === 'duplicate') return 'هذا الاسم مستعمل في الجلسة. أضف ما يميّزك (مثل اللقب).';
    if (code === 'started') return 'بدأت الجلسة بالفعل. انتظر الجلسة القادمة.';
    if (code === 'name') return 'اكتب اسمًا صحيحًا (حرفان على الأقل).';
    if (code === 'full') return 'الجلسة ممتلئة. أبلغ المدرب.';
    if (code === 'net') return 'تعذّر الوصول إلى هاتف المدرب. تأكّد أنك متّصل بنقطة اتصاله، وأوقف البيانات المحمولة، ثم أعد المحاولة.';
    if (code === 'offline') return 'لم يُعثر على المدرب. اتصل بشبكة Wi-Fi الخاصة به، أو اكتب عنوانه في خانة «عنوان هاتف المدرب».';
    return 'تعذّر الانضمام. تحقّق من الشبكة ثم أعد المحاولة.';
  }

  function joinError(message) {
    const box = $('#joinError');
    box.textContent = message;
    box.hidden = false;
    toast(message);
  }

  /* ------------------------------------------------------------------ */
  /* الأسئلة                                                            */
  /* ------------------------------------------------------------------ */

  function showLobby(state) {
    $('#lobbyName').textContent = session.name || '—';
    $('#lobbyTitle').textContent = session.title || 'جلسة أكاديمية الحلبة';
    $('#lobbyTotal').textContent = session.total ? isolate(String(session.total)) : '—';
    $('#lobbyDuration').textContent = session.durationSec ? durationLabel(session.durationSec) : '—';
    $('#lobbyIp').textContent = isolate(`${session.ip}:${PORT}`);
    show('screenLobby');
  }

  function loadQuestions(state) {
    request(session.ip, `/questions?token=${encodeURIComponent(session.token)}`, null, 5000).then((data) => {
      if (!data.ok) {
        if (data.error === 'waiting') {
          showLobby(state || {});
          return;
        }
        throw new Error(data.error || 'questions');
      }
      netOk();
      session.questions = data.questions || [];
      session.total = session.questions.length;
      session.answers = new Array(session.total).fill(-1);

      if (state && state.answers) {
        Object.keys(state.answers).forEach((key) => {
          const index = Number(key);
          if (index >= 0 && index < session.total) session.answers[index] = state.answers[key];
        });
      }

      let firstUnanswered = session.answers.indexOf(-1);
      session.index = firstUnanswered >= 0 ? firstUnanswered : 0;
      session.deadline = Date.now() + ((state && state.remainingMs) || 0);
      session.ended = Boolean(state && state.phase === 'ended');
      pending = {};

      show('screenQuiz');
      renderQuestion();
      startTick();
      startPolling();
      if (session.ended) submitNow(true);
    }).catch((error) => {
      if (error.message === 'waiting') {
        showLobby(state || {});
        return;
      }
      netFail();
      setTimeout(() => {
        if (session && !session.questions.length) loadQuestions(state);
      }, 1800);
    });
  }

  function renderQuestion() {
    const question = session.questions[session.index];
    if (!question) return;

    $('#examName').textContent = session.name || '';
    $('#examCounter').textContent = isolate(`${session.index + 1} / ${session.total}`);
    $('#examQNumber').textContent = `السؤال ${session.index + 1}`;
    $('#examQLevel').textContent = question.level || '';
    $('#examQTitle').textContent = question.q;

    const image = $('#examImage');
    image.src = question.img;
    image.alt = question.alt || question.q;
    $('#examMedia').hidden = !question.img;

    $('#examOptions').innerHTML = question.options.map((option, index) => `
      <button class="exam-option${session.answers[session.index] === index ? ' is-selected' : ''}" type="button" data-index="${index}">
        <span class="exam-option-letter">${'أبجد'[index] || String(index + 1)}</span>
        <span>${esc(option)}</span>
      </button>`).join('');

    $('#examProgressBar').style.width = `${((session.index + 1) / session.total) * 100}%`;
    $('#answeredCount').textContent = isolate(`${answeredCount()} / ${session.total}`);
    $('#prevBtn').disabled = session.index === 0;
    $('#nextBtn').disabled = session.index === session.total - 1;

    renderDots();
    updateTimer();
  }

  function renderDots() {
    $('#examDots').innerHTML = session.questions.map((question, index) => {
      const classes = ['exam-dot'];
      if (session.answers[index] >= 0) classes.push('is-answered');
      if (index === session.index) classes.push('is-current');
      return `<button class="${classes.join(' ')}" type="button" data-dot="${index}" aria-label="السؤال ${index + 1}">${isolate(String(index + 1))}</button>`;
    }).join('');
  }

  function answeredCount() {
    return session.answers.filter((answer) => answer >= 0).length;
  }

  function selectOption(index) {
    if (!session || session.ended) return;
    session.answers[session.index] = index;
    $$('#examOptions .exam-option').forEach((button, buttonIndex) => {
      button.classList.toggle('is-selected', buttonIndex === index);
    });
    $('#answeredCount').textContent = isolate(`${answeredCount()} / ${session.total}`);
    renderDots();
    pending[session.index] = index;
    flush();
  }

  function goTo(index) {
    if (!session || index < 0 || index >= session.total) return;
    session.index = index;
    renderQuestion();
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  /* ------------------------------------------------------------------ */
  /* حفظ الإجابات                                                       */
  /* ------------------------------------------------------------------ */

  function flush() {
    if (!session) return Promise.resolve();
    if (flushPromise) return flushPromise;

    const keys = Object.keys(pending);
    if (!keys.length) return Promise.resolve();

    flushPromise = Promise.all(keys.map((key) => {
      const index = Number(key);
      return post(session.ip, '/answer', {
        token: session.token,
        index,
        choice: pending[key]
      }).then((data) => {
        if (data && data.ok) {
          delete pending[key];
          netOk();
        }
      }).catch(() => {
        netFail();
      });
    })).then(() => {
      flushPromise = null;
      if (Object.keys(pending).length) scheduleRetry();
    });

    return flushPromise;
  }

  function flushAll(rounds) {
    const round = rounds || 0;
    return flush().then(() => {
      if (!Object.keys(pending).length || round >= 4) return null;
      return new Promise((resolve) => {
        setTimeout(resolve, 350);
      }).then(() => flushAll(round + 1));
    });
  }

  function scheduleRetry() {
    if (retryTimer) return;
    retryTimer = setTimeout(() => {
      retryTimer = null;
      flush();
    }, 2500);
  }

  /* ------------------------------------------------------------------ */
  /* المؤقّت                                                            */
  /* ------------------------------------------------------------------ */

  function startTick() {
    if (tickTimer) clearInterval(tickTimer);
    tickTimer = setInterval(updateTimer, 500);
    updateTimer();
  }

  function updateTimer() {
    if (!session) return;
    const timer = $('#examTimer');
    if (!timer) return;
    const remaining = Math.max(0, (session.deadline || 0) - Date.now());
    timer.textContent = formatClock(remaining);
    timer.classList.toggle('is-low', remaining <= 60000 && remaining > 0);
    // Ne jamais soumettre depuis la salle d'attente : tant que l'épreuve n'a
    // pas commencé, la date limite vaut 0. On exige donc une échéance réelle
    // et l'écran du QCM affiché.
    const inQuiz = !$('#screenQuiz').hidden;
    if (inQuiz && session.deadline > 0 && remaining <= 0 && !session.ended) {
      session.ended = true;
      submitNow(true);
    }
  }

  /* ------------------------------------------------------------------ */
  /* الإرسال                                                            */
  /* ------------------------------------------------------------------ */

  function submitNow(auto) {
    if (!session || submitting) return;

    if (!auto) {
      const unanswered = session.total - answeredCount();
      const message = unanswered > 0
        ? `لديك ${unanswered} سؤالًا دون إجابة. هل تريد إنهاء النسخة وإرسالها؟`
        : 'هل تريد إنهاء النسخة وإرسالها إلى المدرب؟';
      if (!window.confirm(message)) return;
    }

    submitting = true;
    $('#submitBtn').disabled = true;
    $('#submitBtn').textContent = 'جارٍ الإرسال…';

    flushAll().then(() => {
      return post(session.ip, '/submit', { token: session.token });
    }).then((data) => {
      if (!data.ok) throw new Error(data.error || 'submit');
      submitting = false;
      showDone(data.score, data.total, data.timeMs);
    }).catch(() => {
      submitting = false;
      $('#submitBtn').disabled = false;
      $('#submitBtn').textContent = 'إنهاء وإرسال النسخة';
      netFail();
      toast('تعذّر الإرسال. تُحفظ إجاباتك وسنعيد المحاولة.');
      setTimeout(() => {
        if (session && !session.submitted) submitNow(true);
      }, 2500);
    });
  }

  function showDone(score, total, timeMs) {
    if (!session) return;
    session.submitted = true;
    stopPolling();
    if (tickTimer) clearInterval(tickTimer);
    tickTimer = null;

    const percent = total ? Math.round((score * 100) / total) : 0;
    $('#doneRing').style.setProperty('--pct', percent);
    $('#donePercent').textContent = isolate(`${percent}%`);
    $('#doneName').textContent = session.name;
    $('#doneScore').textContent = isolate(`${score} / ${total}`);
    $('#doneTime').textContent = formatTime(timeMs);

    let message = 'أُرسلت إجاباتك إلى المدرب.';
    if (percent >= 90) message = 'أداء ممتاز. أُرسلت إجاباتك إلى المدرب.';
    else if (percent >= 75) message = 'نتيجة متينة. أُرسلت إجاباتك إلى المدرب.';
    else if (percent >= 50) message = 'نتيجة مقبولة. أُرسلت إجاباتك إلى المدرب.';
    else message = 'أُرسلت إجاباتك. راجع الدروس قبل الجلسة القادمة.';
    $('#doneMessage').textContent = message;

    try {
      localStorage.setItem(NAME_KEY, session.name);
    } catch (error) {
      /* stockage indisponible */
    }
    clearStored();
    show('screenDone');
  }

  /* ------------------------------------------------------------------ */
  /* المزامنة                                                           */
  /* ------------------------------------------------------------------ */

  function startPolling() {
    if (pollTimer) return;
    pollTimer = setInterval(poll, 2000);
  }

  function stopPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
  }

  function poll() {
    if (!session || session.submitted) return;
    request(session.ip, `/state?token=${encodeURIComponent(session.token)}`, null, 4000).then((state) => {
      if (!state.ok) {
        if (state.error === 'token') leaveSession('لم تعد هذه الجلسة معروفة لدى المدرب.');
        return;
      }
      applyState(state, false);
    }).catch(() => {
      netFail();
    });
  }

  function leaveSession(reason) {
    stopPolling();
    if (tickTimer) clearInterval(tickTimer);
    tickTimer = null;
    session = null;
    pending = {};
    clearStored();
    show('screenJoin');
    prefillJoin();
    if (reason) toast(reason);
  }

  /* ------------------------------------------------------------------ */
  /* الأحداث                                                            */
  /* ------------------------------------------------------------------ */

  function bind() {
    $('#joinForm').addEventListener('submit', (event) => {
      event.preventDefault();
      join();
    });

    $('#codeInput').addEventListener('input', (event) => {
      event.target.value = event.target.value.replace(/\D/g, '').slice(0, 4);
    });

    $('#ipInput').addEventListener('change', () => {
      const ip = normalizeIp($('#ipInput').value);
      if (ip) {
        discoveredIp = ip;
        setNetStatus('ok', `العنوان اليدوي — ${isolate(ip)}`);
      }
    });

    const retry = $('#netRetry');
    if (retry) retry.addEventListener('click', () => discover({ force: true }));

    $('#leaveBtn').addEventListener('click', () => {
      if (window.confirm('مغادرة الجلسة؟ لن تشارك في الامتحان.')) leaveSession(null);
    });

    $('#examOptions').addEventListener('click', (event) => {
      const option = event.target.closest('.exam-option');
      if (option) selectOption(Number(option.dataset.index));
    });

    $('#examDots').addEventListener('click', (event) => {
      const dot = event.target.closest('[data-dot]');
      if (dot) goTo(Number(dot.dataset.dot));
    });

    $('#prevBtn').addEventListener('click', () => goTo(session.index - 1));
    $('#nextBtn').addEventListener('click', () => goTo(session.index + 1));
    $('#submitBtn').addEventListener('click', () => submitNow(false));

    $('#doneCloseBtn').addEventListener('click', () => {
      session = null;
      show('screenJoin');
      prefillJoin();
      discover();
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) return;
      if (session && !session.submitted) {
        poll();
        // Le chronomètre ne concerne que l'épreuve en cours.
        if (!$('#screenQuiz').hidden) updateTimer();
      } else if (!$('#screenJoin').hidden && !joinBusy) {
        discover({ force: true });
      }
    });
  }

  function watchNetwork() {
    if (watchTimer) return;
    let lastSweep = Date.now();
    watchTimer = setInterval(() => {
      if (document.hidden || joinBusy || session) return;
      if ($('#screenJoin').hidden) return;
      if (discoveredIp) {
        ping(discoveredIp).catch(() => {
          discoveredIp = null;
        });
        return;
      }
      // Un balayage complet est coûteux : au plus un toutes les 20 secondes.
      if (Date.now() - lastSweep < 20000) return;
      lastSweep = Date.now();
      discover({ force: true });
    }, 7000);
  }

  function prefillJoin() {
    try {
      const name = localStorage.getItem(NAME_KEY);
      if (name) $('#nameInput').value = name;
    } catch (error) {
      /* stockage indisponible */
    }
    $('#codeInput').value = '';
    $('#joinError').hidden = true;
    $('#ipInput').value = '';
    setTimeout(() => {
      const target = $('#nameInput').value ? $('#codeInput') : $('#nameInput');
      if (target) target.focus();
    }, 150);
  }

  /* ------------------------------------------------------------------ */
  /* الانطلاق                                                           */
  /* ------------------------------------------------------------------ */

  bind();
  prefillJoin();
  resume();
  watchNetwork();

  window.RingExam = {
    reset: () => {
      clearStored();
      session = null;
      stopPolling();
      show('screenJoin');
      prefillJoin();
    }
  };
})();
