/* =========================================================
   أكاديمية الحلبة — تطبيق الدروس
   المحتوى: js/courses/*.js + js/catalog.js
   التخزين: localStorage · دون إنترنت.
   ========================================================= */

(() => {
  'use strict';

  const STORE_KEY = 'ringAcademy.cours.v1';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));

  const isolate = (value) => `\u2066${value}\u2069`;

  let state = loadState();
  let toastTimer = null;

  function courseList() {
    return window.RingCatalog ? RingCatalog.courses : [];
  }

  function currentCourse() {
    const courses = courseList();
    return courses.find((course) => course.id === state.courseId) || courses[0] || null;
  }

  function currentModules() {
    const course = currentCourse();
    return course ? course.modules : [];
  }

  function loadState() {
    const base = { courseId: '', modulesRead: {} };
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return base;
      const parsed = JSON.parse(raw);
      return {
        courseId: parsed && typeof parsed.courseId === 'string' ? parsed.courseId : '',
        modulesRead: parsed && parsed.modulesRead && typeof parsed.modulesRead === 'object' ? parsed.modulesRead : {}
      };
    } catch (error) {
      return base;
    }
  }

  function saveState() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(state));
    } catch (error) {
      /* stockage indisponible : la progression reste en mémoire */
    }
  }

  function readModules() {
    return currentModules().filter((module) => state.modulesRead[module.id]).length;
  }

  function currentView() {
    return (location.hash || '#accueil').replace(/^#/, '').split('/')[0] || 'accueil';
  }

  function pointsLabel(count) {
    if (count === 1) return 'نقطة واحدة';
    if (count === 2) return 'نقطتان';
    if (count >= 3 && count <= 10) return `${count} نقاط`;
    return `${count} نقطة`;
  }

  function updateCounts() {
    const course = currentCourse();
    const counts = {
      modules: course ? course.modules.length : 0,
      signals: window.SIGNALS ? SIGNALS.length : 0,
      questions: course ? course.questions.length : 0,
      courses: courseList().length
    };
    Object.keys(counts).forEach((key) => {
      $$(`[data-count-${key}]`).forEach((element) => {
        element.textContent = counts[key];
      });
    });
  }

  /* ------------------------------------------------------------------ */
  /* اختيار الكورس                                                      */
  /* ------------------------------------------------------------------ */

  function pickerHtml() {
    const course = currentCourse();
    return courseList().map((item) => {
      const active = course && item.id === course.id;
      return `<button type="button" class="cours-course-chip${active ? ' is-active' : ''}"
        data-course-id="${esc(item.id)}" aria-pressed="${active ? 'true' : 'false'}">
        <span>${esc(item.short)}</span>
        <small>${isolate(item.modules.length)}</small>
      </button>`;
    }).join('');
  }

  function renderPickers() {
    ['#homeCourses', '#coursePicker', '#progressCourses'].forEach((selector) => {
      const element = $(selector);
      if (element) element.innerHTML = pickerHtml();
    });
  }

  function selectCourse(id) {
    if (!courseList().some((course) => course.id === id)) return;
    if (state.courseId === id) return;
    state.courseId = id;
    saveState();
    renderPickers();
    updateCounts();
    const view = currentView();
    if (view === 'lecon') {
      location.hash = '#cours';
      return;
    }
    if (view === 'accueil') renderHome();
    else if (view === 'cours') renderCourse();
    else if (view === 'progression') renderProgress();
    toast('تم اختيار الكورس.');
  }

  /* ------------------------------------------------------------------ */
  /* الرئيسية                                                           */
  /* ------------------------------------------------------------------ */

  function moduleCard(module) {
    const read = Boolean(state.modulesRead[module.id]);
    return `
      <a class="module-card${read ? ' is-read' : ''}" href="#lecon/${esc(module.id)}">
        <div class="module-cover">
          <img src="${esc(module.img)}" alt="${esc(module.title)}">
          <span class="module-read">مقروءة</span>
          <span class="module-number">${esc(module.number)}</span>
        </div>
        <div class="module-body">
          <span class="module-course">${esc(module.courseShort || '')}</span>
          <h3>${esc(module.title)}</h3>
          <p>${esc(module.subtitle)}</p>
          <div class="module-foot">
            <span>${esc(module.duration)} · ${esc(pointsLabel(module.points.length))}</span>
            <span>افتح ←</span>
          </div>
        </div>
      </a>`;
  }

  function signalPreview(signal) {
    const src = signal.src || `assets/img/${signal.file}`;
    return `
      <button class="signal-preview" type="button"
        data-lightbox="${esc(src)}"
        data-caption="${esc(signal.name)} — ${esc(signal.desc)}">
        <img src="${esc(src)}" alt="${esc(signal.name)}">
        <strong>${esc(signal.name)}</strong>
      </button>`;
  }

  function signalCard(signal) {
    const src = signal.src || `assets/img/${signal.file}`;
    return `
      <button class="signal-card" type="button"
        data-lightbox="${esc(src)}"
        data-caption="${esc(signal.name)} — ${esc(signal.desc)}">
        <img src="${esc(src)}" alt="${esc(signal.name)}">
        <strong>${esc(signal.name)}</strong>
        <small>${esc(signal.desc)}</small>
      </button>`;
  }

  function renderHome() {
    const modules = currentModules();
    const read = readModules();
    const pct = modules.length ? Math.round((read / modules.length) * 100) : 0;

    renderPickers();
    updateCounts();

    $('#homeRead').textContent = isolate(`${read} / ${modules.length}`);
    $('#homeRing').style.setProperty('--pct', pct);
    $('#homeBar').style.width = `${pct}%`;

    const pill = $('#homePill');
    pill.textContent = read === 0 ? 'جديد' : read === modules.length ? 'مكتمل' : 'في تقدّم';

    let note = 'ابدأ بالوحدة الأولى.';
    if (read === modules.length) note = 'أتممت هذا الكورس. جرّب الكورس الآخر.';
    else if (read > 0) note = `بقيت ${modules.length - read} وحدات للقراءة.`;
    $('#homeNote').textContent = note;

    $('#homeModules').innerHTML = modules.map(moduleCard).join('');
    $('#homeSignals').innerHTML = SIGNALS.slice(0, 8).map(signalPreview).join('');
  }

  /* ------------------------------------------------------------------ */
  /* البرنامج                                                           */
  /* ------------------------------------------------------------------ */

  function updateCourseMeter() {
    const modules = currentModules();
    const read = readModules();
    const pct = modules.length ? Math.round((read / modules.length) * 100) : 0;
    $('#courseReadCount').textContent = isolate(`${read} / ${modules.length}`);
    $('#courseReadBar').style.width = `${pct}%`;

    let note = 'ابدأ بالوحدة 1.';
    if (read === modules.length) note = 'أتممت هذا الكورس. حان وقت مراجعة الإشارات.';
    else if (read > 0) note = `بقيت ${modules.length - read} وحدات للقراءة.`;
    $('#courseReadNote').textContent = note;
  }

  function renderCourse() {
    const modules = currentModules();
    renderPickers();
    updateCounts();
    updateCourseMeter();
    $('#courseList').innerHTML = modules.map((module) => {
      const read = Boolean(state.modulesRead[module.id]);
      return `
        <a class="course-item" href="#lecon/${esc(module.id)}">
          <div class="course-thumb">
            <img src="${esc(module.img)}" alt="${esc(module.title)}">
            <span>${esc(module.number)}</span>
          </div>
          <div class="course-info">
            <h3>${esc(module.title)}${read ? '<span class="read-dot" aria-label="وحدة مقروءة"></span>' : ''}</h3>
            <p>${esc(module.subtitle)} ${esc(module.intro)}</p>
            <div class="course-info-meta">
              <span>${esc(module.duration)}</span>
              <span>${esc(pointsLabel(module.points.length))}</span>
              <span>${read ? 'مقروءة' : 'للقراءة'}</span>
            </div>
          </div>
          <div class="course-cta">
            <span>${read ? 'إعادة القراءة' : 'ابدأ'}</span>
            <span class="arrow-circle" aria-hidden="true">←</span>
          </div>
        </a>`;
    }).join('');
  }

  /* ------------------------------------------------------------------ */
  /* الدرس                                                              */
  /* ------------------------------------------------------------------ */

  function renderLesson(id) {
    const modules = currentModules();
    const module = modules.find((item) => item.id === id);
    if (!module) {
      location.replace('#cours');
      return;
    }

    const read = Boolean(state.modulesRead[module.id]);
    const index = modules.indexOf(module);
    const previous = modules[index - 1];
    const next = modules[index + 1];
    const course = currentCourse();

    const commands = module.commands ? `
      <div class="commands-card">
        <h3>الأوامر الأساسية</h3>
        ${module.commands.map(([command, meaning]) => `
          <div class="command-row">
            <strong>${esc(command)}</strong>
            <span>${esc(meaning)}</span>
          </div>`).join('')}
      </div>` : '';

    const signals = module.key === 'signaux' ? `
      <div class="lesson-signals">
        <h2>${SIGNALS.length} إشارة بالصور</h2>
        <p>اضغط على إشارة لتكبيرها.</p>
        <div class="signal-grid">${SIGNALS.map(signalCard).join('')}</div>
      </div>` : '';

    $('#lessonContent').innerHTML = `
      <a class="icon-text-btn" href="#cours" data-nav="cours">
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M12 5l-5 5 5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
        ${esc(course ? course.name : 'البرنامج')}
      </a>

      <div class="lesson-hero" style="margin-top:14px">
        <img src="${esc(module.img)}" alt="${esc(module.title)}">
        <div class="lesson-hero-body">
          <span class="lesson-num">${esc(course ? course.short : '')} · الوحدة ${esc(module.number)}</span>
          <h1>${esc(module.title)}</h1>
          <p>${esc(module.intro)}</p>
          <div class="lesson-meta">
            <span>${esc(module.duration)}</span>
            <span>${esc(pointsLabel(module.points.length))}</span>
            <span>${read ? 'مقروءة' : 'للقراءة'}</span>
          </div>
        </div>
      </div>

      <div class="lesson-grid">
        <div class="lesson-main">
          <h2>ما يجب حفظه</h2>
          <ul class="lesson-points">
            ${module.points.map((point, pointIndex) => `
              <li>
                <span class="num">${pointIndex + 1}</span>
                <span>${esc(point)}</span>
              </li>`).join('')}
          </ul>
          ${signals}
        </div>

        <aside class="lesson-side">
          <div class="memo-card">
            <span>الخلاصة</span>
            <p>${esc(module.memo)}</p>
          </div>
          <div class="side-actions">
            <a class="btn btn-primary" href="${next ? `#lecon/${esc(next.id)}` : '#signaux'}"${next ? '' : ' data-nav="signaux"'}>
              ${next ? 'الوحدة التالية ←' : 'مراجعة الإشارات ←'}
            </a>
            <button class="read-toggle${read ? ' is-read' : ''}" type="button" data-toggle-read="${esc(module.id)}">
              <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12.5 9.5 17 19 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
              ${read ? 'وحدة مقروءة — إزالة' : 'تعليمها كمقروءة'}
            </button>
          </div>
          ${commands}
        </aside>
      </div>

      <nav class="lesson-nav" aria-label="التنقّل بين الوحدات">
        ${previous ? `
          <a href="#lecon/${esc(previous.id)}">
            <small>السابق</small>
            <strong>→ ${esc(previous.title)}</strong>
          </a>` : ''}
        ${next ? `
          <a class="next" href="#lecon/${esc(next.id)}">
            <small>التالي</small>
            <strong>${esc(next.title)} ←</strong>
          </a>` : ''}
      </nav>`;
  }

  /* ------------------------------------------------------------------ */
  /* الإشارات                                                           */
  /* ------------------------------------------------------------------ */

  function renderSignals() {
    updateCounts();
    $('#signalGrid').innerHTML = SIGNALS.map(signalCard).join('');
  }

  /* ------------------------------------------------------------------ */
  /* التقدّم                                                            */
  /* ------------------------------------------------------------------ */

  function renderProgress() {
    const modules = currentModules();
    const read = readModules();
    const pct = modules.length ? Math.round((read / modules.length) * 100) : 0;
    const course = currentCourse();
    const rows = modules.map((module) => {
      const isRead = Boolean(state.modulesRead[module.id]);
      return `
        <a class="${isRead ? 'is-read' : ''}" href="#lecon/${esc(module.id)}">
          <span class="num">${esc(module.number)}</span>
          <strong>${esc(module.title)}</strong>
          <small>${isRead ? 'مقروءة' : 'للقراءة'}</small>
        </a>`;
    }).join('');

    renderPickers();
    updateCounts();

    $('#progressContent').innerHTML = `
      <div class="cours-progress-panel">
        <span class="kicker">${esc(course ? course.short : 'الحصيلة')}</span>
        <h2>\u2067${read} من ${modules.length} وحدات مقروءة\u2069</h2>
        <p>${read === modules.length ? 'أتممت هذا الكورس كاملًا. حافظ على المراجعة القصيرة والمنتظمة.' : 'كل وحدة تقرأها تثبّت جزءًا من الصورة. لا تستعجل.'}</p>
        <div class="meter" style="margin-top:16px"><span style="width:${pct}%"></span></div>
        <div class="cours-module-status">${rows}</div>
      </div>`;
  }

  /* ------------------------------------------------------------------ */
  /* أدوات مشتركة                                                       */
  /* ------------------------------------------------------------------ */

  function toast(message) {
    const element = $('#toast');
    if (!element) return;
    element.textContent = message;
    element.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => element.classList.remove('is-visible'), 2600);
  }

  function openLightbox(src, caption) {
    const lightbox = $('#lightbox');
    $('#lightboxImg').src = src;
    $('#lightboxImg').alt = caption;
    $('#lightboxCaption').textContent = caption;
    lightbox.hidden = false;
    document.body.classList.add('no-scroll');
  }

  function closeLightbox() {
    $('#lightbox').hidden = true;
    document.body.classList.remove('no-scroll');
  }

  function resetProgress() {
    if (!window.confirm('إعادة تصفير تقدّم القراءة؟ لا يمكن التراجع.')) return;
    state = { courseId: state.courseId, modulesRead: {} };
    saveState();
    toast('أُعيد تصفير التقدّم.');
    renderProgress();
    if (currentView() === 'cours') renderCourse();
    if (currentView() === 'lecon') {
      const id = (location.hash || '').split('/')[1];
      if (id) renderLesson(id);
    }
  }

  function closeMenu() {
    $('#mainNav').classList.remove('is-open');
    $('#menuBtn').setAttribute('aria-expanded', 'false');
    $('#menuBtn').setAttribute('aria-label', 'فتح القائمة');
  }

  function toggleMenu() {
    const open = $('#mainNav').classList.toggle('is-open');
    $('#menuBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
    $('#menuBtn').setAttribute('aria-label', open ? 'إغلاق القائمة' : 'فتح القائمة');
  }

  /* ------------------------------------------------------------------ */
  /* التوجيه                                                            */
  /* ------------------------------------------------------------------ */

  const VIEWS = ['accueil', 'cours', 'lecon', 'signaux', 'progression'];
  const TITLES = {
    accueil: 'الرئيسية',
    cours: 'البرنامج',
    lecon: 'الدرس',
    signaux: 'الإشارات',
    progression: 'التقدّم'
  };

  function route() {
    const raw = (location.hash || '#accueil').replace(/^#/, '') || 'accueil';
    const parts = raw.split('/');
    const view = parts[0];
    const param = parts[1];

    if (VIEWS.indexOf(view) < 0) {
      location.replace('#accueil');
      return;
    }
    if (view === 'lecon' && !currentModules().some((module) => module.id === param)) {
      location.replace('#cours');
      return;
    }

    closeMenu();
    $$('.view').forEach((element) => { element.hidden = true; });
    const target = $(`#view-${view}`);
    if (target) target.hidden = false;

    const navMap = { lecon: 'cours' };
    const navKey = navMap[view] || view;
    $$('.main-nav a').forEach((link) => {
      link.classList.toggle('is-active', link.dataset.nav === navKey);
    });

    document.title = `${TITLES[view] || 'الدروس'} — أكاديمية الحلبة`;
    if (view === 'lecon') {
      const module = currentModules().find((item) => item.id === param);
      if (module) document.title = `${module.title} — أكاديمية الحلبة`;
    }

    if (view === 'accueil') renderHome();
    else if (view === 'cours') renderCourse();
    else if (view === 'lecon') renderLesson(param);
    else if (view === 'signaux') renderSignals();
    else if (view === 'progression') renderProgress();

    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  /* ------------------------------------------------------------------ */
  /* الأحداث                                                            */
  /* ------------------------------------------------------------------ */

  function handleGlobalClick(event) {
    if (event.target.closest('[data-nav]')) closeMenu();

    const courseChip = event.target.closest('[data-course-id]');
    if (courseChip) {
      selectCourse(courseChip.dataset.courseId);
      return;
    }

    const lightboxTrigger = event.target.closest('[data-lightbox]');
    if (lightboxTrigger) {
      event.preventDefault();
      openLightbox(lightboxTrigger.dataset.lightbox, lightboxTrigger.dataset.caption || '');
      return;
    }

    const readButton = event.target.closest('[data-toggle-read]');
    if (readButton) {
      const id = readButton.dataset.toggleRead;
      const module = currentModules().find((item) => item.id === id);
      if (!module) return;
      const wasRead = Boolean(state.modulesRead[id]);
      if (wasRead) delete state.modulesRead[id];
      else state.modulesRead[id] = true;
      saveState();
      toast(wasRead ? 'أُزيل تعليم الوحدة كمقروءة.' : 'عُلّمت الوحدة كمقروءة.');
      if (currentView() === 'lecon') renderLesson(id);
      if (currentView() === 'cours') renderCourse();
      if (currentView() === 'progression') renderProgress();
      return;
    }
  }

  function bindEvents() {
    $('#menuBtn').addEventListener('click', toggleMenu);
    document.addEventListener('click', handleGlobalClick);

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        if (!$('#lightbox').hidden) { closeLightbox(); return; }
        closeMenu();
      }
    });

    $('#lightboxClose').addEventListener('click', closeLightbox);
    $('#lightbox').addEventListener('click', (event) => {
      if (event.target === $('#lightbox')) closeLightbox();
    });

    $('#resetProgressBtn').addEventListener('click', resetProgress);
    window.addEventListener('hashchange', route);
  }

  function init() {
    $('#year').textContent = new Date().getFullYear();
    const courses = courseList();
    if (courses.length && !courses.some((course) => course.id === state.courseId)) {
      state.courseId = courses[0].id;
      saveState();
    }
    bindEvents();
    route();
  }

  init();
})();
